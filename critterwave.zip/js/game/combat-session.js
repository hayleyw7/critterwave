import { canUseCombatActions as canUseCombatActionsGate, finishCombatAction as finishCombatActionGate, tryLockCombat as tryLockCombatGate, } from "./lib/combat-gate.js";
import { gameState } from "./state.js";
export function combatGateState() {
    return {
        phase,
        combatBusy,
        awaitingFoeResponse,
        combatActionGeneration,
        playerHp: gameState.player.hp,
        hasFoe: gameState.foe !== null,
    };
}
export function applyCombatGateState(state) {
    gameState.combatBusy = state.combatBusy;
    gameState.awaitingFoeResponse = state.awaitingFoeResponse;
    gameState.combatActionGeneration = state.combatActionGeneration;
}
export function canUseCombatActions() {
    return canUseCombatActionsGate(combatGateState());
}
/** Returns action generation id when locked; null if actions are not allowed. */
export function lockCombat() {
    const locked = tryLockCombatGate(combatGateState());
    if (!locked.ok) {
        return null;
    }
    applyCombatGateState(locked.state);
    return locked.generation;
}
export function finishCombatAction(generation) {
    applyCombatGateState(finishCombatActionGate(generation, combatGateState()));
    syncCombatHintClasses();
}
