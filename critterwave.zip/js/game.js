import { init } from "./game/app.js";
void init();
