import { el } from "./game/dom.js";
import { gameState } from "./state.js";
export function bindActions() {
    el.actions.addEventListener("click", (event) => {
        const target = event.target.closest("[data-action]");
        if (!target)
            return;
        const action = target.dataset.action;
        if (!canUseCombatActions())
            return;
        switch (action) {
            case "attack":
                onAttack();
                break;
            case "heal":
                onHeal();
                break;
            case "dance":
                onDance();
                break;
            case "run":
                onRun();
                break;
        }
        target.blur();
    });
    el.restartBtn.addEventListener("click", () => {
        resetGame();
    });
    el.quitBtn.addEventListener("click", () => {
        void startNewGame();
    });
    el.resetStatsBtn.addEventListener("click", () => {
        void resetStats();
    });
    el.themeToggle.addEventListener("click", () => {
        toggleColorMode();
    });
    el.heroNameInput.addEventListener("input", () => {
        updateSetupStartButton();
        persistSetupDraft();
    });
    bindSetupColorPicker();
    el.setupStartBtn.addEventListener("click", () => {
        if (!confirmHeroAndStart()) {
            return;
        }
        if (!gameState.foe) {
            void beginGame();
        }
        else {
            render();
            persist();
        }
    });
}
