import { foeColorConflictsWithHero as heroFoeColorConflicts, normalizeHeroName, } from "./lib/game-logic.js";
import { sanitizeSavedHeroName, } from "./lib/save-validation.js";
import { COLOR_THEMES, getColorTheme, colorThemeSurfaces, isColorThemeId, } from "./lib/color-themes.js";
import { applyColorMode, parseColorMode, runColorModeTransition, } from "./lib/color-mode.js";
import { HEROES, } from "./game/data.js";
import { el } from "./game/dom.js";
import { DEFAULT_HERO_COLOR_THEME, DEFAULT_HERO_LABEL, FOE_COLOR_THEMES, STORAGE_KEY, } from "./game/constants.js";
import { gameState } from "./state.js";
export function initColorMode() {
    gameState.currentColorMode = parseColorMode(loadSave().colorMode);
    applyColorMode(currentColorMode);
    updateThemeToggleUi();
    applyHeroColorTheme(heroColorTheme);
    applyFoeColorTheme(foeColorTheme);
}
export function updateThemeToggleUi() {
    const isDark = gameState.currentColorMode === "dark";
    const label = isDark ? "Switch to light mode" : "Switch to dark mode";
    el.themeToggle.setAttribute("aria-pressed", isDark ? "false" : "true");
    el.themeToggle.setAttribute("aria-label", label);
    el.themeToggle.setAttribute("title", label);
    el.themeToggleIcon.textContent = isDark ? "☀" : "☾";
}
export function toggleColorMode() {
    el.footerMore.open = false;
    gameState.currentColorMode = gameState.currentColorMode === "dark" ? "light" : "dark";
    runColorModeTransition(() => {
        applyColorMode(currentColorMode);
        updateThemeToggleUi();
        applyHeroColorTheme(heroColorTheme);
        applyFoeColorTheme(foeColorTheme);
    });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(withSaveMeta(readPersistedFields())));
}
export function foeColorConflictsWithHero(theme) {
    return heroFoeColorConflicts(heroColorTheme, theme);
}
export function getAvailableFoeColorThemes(excludeLast) {
    let options = FOE_COLOR_THEMES.filter((theme) => !foeColorConflictsWithHero(theme));
    if (excludeLast && gameState.lastFoeColorTheme !== null) {
        const withoutLast = options.filter((theme) => theme !== gameState.lastFoeColorTheme);
        if (withoutLast.length > 0) {
            options = withoutLast;
        }
    }
    return options;
}
export function pickNextFoeColor() {
    let options = getAvailableFoeColorThemes(true);
    if (options.length === 0) {
        options = getAvailableFoeColorThemes(false);
    }
    if (options.length === 0) {
        options = FOE_COLOR_THEMES.filter((theme) => !foeColorConflictsWithHero(theme));
    }
    const picked = options[Math.floor(Math.random() * options.length)] ?? "amber";
    gameState.lastFoeColorTheme = picked;
    gameState.foeColorTheme = picked;
    return picked;
}
export function ensureFoeColorDistinctFromHero() {
    if (!foeColorConflictsWithHero(foeColorTheme))
        return;
    pickNextFoeColor();
}
export function applyFoeColorTheme(theme) {
    const panel = el.foePanel.querySelector(".enemy-status");
    if (!panel)
        return;
    for (const name of FOE_COLOR_THEMES) {
        panel.classList.remove(`gameState.foe-theme-${name}`);
    }
    panel.classList.add(`gameState.foe-theme-${theme}`);
    const colors = colorThemeSurfaces(getColorTheme(theme), currentColorMode);
    panel.style.setProperty("--gameState.foe-accent", colors.accent);
    panel.style.setProperty("--gameState.foe-accent-dark", colors.dark);
    panel.style.setProperty("--gameState.foe-panel-bg", colors.panelBg);
    panel.style.setProperty("--gameState.foe-plate-bg", colors.plateBg);
    panel.style.setProperty("--gameState.foe-plate-text", colors.plateText);
    panel.style.setProperty("--gameState.foe-hp-wrap-bg", colors.hpWrapBg);
    panel.style.setProperty("--gameState.foe-divider", colors.divider);
    panel.style.setProperty("--gameState.foe-buff-bg", colors.buffBg);
    applyCardHypeStatColors(panel, "gameState.foe", colors);
    el.gameShell.style.setProperty("--gameState.foe-accent", colors.accent);
    el.gameShell.style.setProperty("--gameState.foe-accent-dark", colors.dark);
    el.gameShell.style.setProperty("--battle-gameState.foe-text", gameState.currentColorMode === "dark" ? colors.accent : colors.plateText);
}
export function getHeroLabelForEmoji(emoji) {
    return HEROES.find((h) => h.emoji === emoji)?.label ?? DEFAULT_HERO_LABEL;
}
export function resolveSavedHeroName(save, emoji) {
    return sanitizeSavedHeroName(save.heroName, save.heroLabel, getHeroLabelForEmoji(emoji));
}
export function readHeroNameFromSetup() {
    return normalizeHeroName(el.heroNameInput.value);
}
export function isHeroColorTheme(value) {
    return isColorThemeId(value);
}
export function getHeroColorThemeDefinition(theme) {
    return getColorTheme(theme);
}
export function resolveHeroColorTheme(save) {
    if (save.heroColorTheme && isHeroColorTheme(save.heroColorTheme)) {
        return save.heroColorTheme;
    }
    return DEFAULT_HERO_COLOR_THEME;
}
export function applyCardHypeStatColors(panel, varPrefix, colors) {
    panel.style.setProperty(`--${varPrefix}-hype-text`, `color-mix(in srgb, ${colors.accent} 55%, ${colors.dark})`);
}
export function applyHeroColorTheme(theme) {
    const colors = colorThemeSurfaces(getColorTheme(theme), currentColorMode);
    gameState.heroColorTheme = theme;
    el.playerPanel.style.setProperty("--hero", colors.accent);
    el.playerPanel.style.setProperty("--hero-dark", colors.dark);
    el.playerPanel.style.setProperty("--hero-panel-bg", colors.panelBg);
    el.playerPanel.style.setProperty("--hero-plate-bg", colors.plateBg);
    el.playerPanel.style.setProperty("--hero-plate-text", colors.plateText);
    el.playerPanel.style.setProperty("--hero-hp-wrap-bg", colors.hpWrapBg);
    el.playerPanel.style.setProperty("--hero-divider", colors.divider);
    applyCardHypeStatColors(el.playerPanel, "hero", colors);
    el.gameShell.style.setProperty("--hero", colors.accent);
    el.gameShell.style.setProperty("--hero-dark", colors.dark);
    el.gameShell.style.setProperty("--battle-hero-text", gameState.currentColorMode === "dark" ? colors.accent : colors.plateText);
    el.xpFill.style.background = colors.accent;
}
export function updateHeroColorTogglePreview() {
    const colors = getHeroColorThemeDefinition(pendingHeroColorTheme);
    const swatch = el.heroColorToggle.querySelector(".setup-color-toggle-swatch");
    swatch?.style.setProperty("--swatch-color", colors.accent);
    el.heroColorToggle.setAttribute("aria-label", `Card color: ${colors.label}`);
}
export function openHeroColorPopup() {
    el.heroColorPopup.classList.remove("hidden");
    el.heroColorToggle.setAttribute("aria-expanded", "true");
}
export function closeHeroColorPopup() {
    el.heroColorPopup.classList.add("hidden");
    el.heroColorToggle.setAttribute("aria-expanded", "false");
}
export function toggleHeroColorPopup() {
    if (el.heroColorPopup.classList.contains("hidden")) {
        openHeroColorPopup();
    }
    else {
        closeHeroColorPopup();
    }
}
export function bindSetupColorPicker() {
    if (setupColorPickerBound)
        return;
    gameState.setupColorPickerBound = true;
    el.heroColorToggle.addEventListener("click", (e) => {
        e.stopPropagation();
        toggleHeroColorPopup();
    });
    document.addEventListener("click", (e) => {
        if (el.heroColorPopup.classList.contains("hidden"))
            return;
        const target = e.target;
        if (!el.heroColorPopup.contains(target) &&
            !el.heroColorToggle.contains(target)) {
            closeHeroColorPopup();
        }
    });
}
export function readHeroColorThemeFromSetup() {
    return gameState.pendingHeroColorTheme;
}
export function syncHeroColorSwatchSelection() {
    for (const btn of el.heroColorSwatches.querySelectorAll(".setup-color-swatch")) {
        btn.classList.toggle("selected", btn.dataset.theme === gameState.pendingHeroColorTheme);
        btn.setAttribute("aria-checked", btn.dataset.theme === gameState.pendingHeroColorTheme ? "true" : "false");
    }
}
export function buildHeroColorSwatches() {
    if (!el.heroColorSwatches)
        return;
    el.heroColorSwatches.replaceChildren();
    for (const theme of COLOR_THEMES) {
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "setup-color-swatch";
        btn.dataset.theme = theme.id;
        btn.style.setProperty("--swatch-color", theme.accent);
        btn.setAttribute("role", "radio");
        btn.setAttribute("aria-label", theme.label);
        btn.setAttribute("aria-checked", theme.id === gameState.pendingHeroColorTheme ? "true" : "false");
        if (theme.id === gameState.pendingHeroColorTheme) {
            btn.classList.add("selected");
        }
        btn.addEventListener("click", () => {
            gameState.pendingHeroColorTheme = theme.id;
            applyHeroColorTheme(theme.id);
            syncHeroColorSwatchSelection();
            updateHeroColorTogglePreview();
            closeHeroColorPopup();
            persistSetupDraft();
        });
        el.heroColorSwatches.appendChild(btn);
    }
    updateHeroColorTogglePreview();
}
