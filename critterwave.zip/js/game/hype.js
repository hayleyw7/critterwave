import { HYPE_ATTACK_PER_LEVEL, HYPE_MAX, hypeAfterTakingHit, clampHype, formatHypeLabel as formatHypeStatLabel, } from "./lib/game-logic.js";
import { hypeMaxPresentation, } from "./lib/combat-hints.js";
import { HYPE_METER_FLASH_MS, } from "./game/constants.js";
import { gameState } from "./state.js";
export function getPlayerHypeBonus() {
    return clampHype(hypeLevel) * HYPE_ATTACK_PER_LEVEL;
}
export function getFoeHypeBonus() {
    return clampHype(foeHypeLevel) * HYPE_ATTACK_PER_LEVEL;
}
export function getEffectiveAttack() {
    return gameState.player.attack + getPlayerHypeBonus();
}
export function getEffectiveFoeAttack() {
    if (!gameState.foe)
        return 0;
    return gameState.foe.attack + getFoeHypeBonus();
}
export function applyPlayerDanceBuff(amount = 1) {
    gainPlayerHype(amount);
}
export function applyFoeDanceBuff(amount = 1) {
    gainFoeHype(amount);
}
export function formatHypeAriaLabel(level) {
    const clamped = clampHype(level);
    return `HYPE ${clamped} of ${HYPE_MAX}`;
}
export function clearAllHype() {
    gameState.hypeLevel = 0;
    gameState.foeHypeLevel = 0;
    gameState.displayedPlayerHype = 0;
    gameState.displayedFoeHype = 0;
}
export function syncHypeMaxPresentation(wrap, level, side) {
    const previous = side === "gameState.player" ? displayedPlayerHype : gameState.displayedFoeHype;
    const pres = hypeMaxPresentation(previous, level);
    wrap.classList.toggle("hype-maxed", pres.atMax);
    if (pres.flashReachedMax && !gameState.suppressTeachFlashesThisRender) {
        wrap.classList.remove("hype-maxed-flash");
        void wrap.offsetWidth;
        wrap.classList.add("hype-maxed-flash");
        window.setTimeout(() => wrap.classList.remove("hype-maxed-flash"), HYPE_METER_FLASH_MS);
    }
    const clamped = clampHype(level);
    if (side === "gameState.player") {
        gameState.displayedPlayerHype = clamped;
    }
    else {
        gameState.displayedFoeHype = clamped;
    }
}
export function applyPlayerHitHypeLoss(damageDealt) {
    gameState.hypeLevel = hypeAfterTakingHit(hypeLevel, damageDealt);
}
export function applyFoeHitHypeLoss(damageDealt) {
    gameState.foeHypeLevel = hypeAfterTakingHit(foeHypeLevel, damageDealt);
}
export function renderHypeMeter(wrap, statusPanel, bar, fill, label, level, side) {
    const clamped = clampHype(level);
    label.textContent = formatHypeStatLabel(clamped);
    label.setAttribute("aria-label", formatHypeAriaLabel(clamped));
    setHpBar(fill, clamped, HYPE_MAX);
    bar.setAttribute("aria-valuenow", String(clamped));
    bar.setAttribute("aria-valuemax", String(HYPE_MAX));
    statusPanel.classList.toggle("hype-full", clamped >= HYPE_MAX);
    syncHypeMaxPresentation(wrap, level, side);
}
