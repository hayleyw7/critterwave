import { DEFEAT_VERBS, applyPlayerHealRoll, isLevelBandFinale, advanceFoeQueueAfterFlee, advanceFoeQueueAfterVictory, buildInitialFoeQueue, nextDefeatVerb as advanceDefeatVerb, playerLevelForWave, randomDamage, } from "./lib/game-logic.js";
import { setBattleLines, } from "./lib/battle-log-dom.js";
import { blockCombatForScreenEnd, } from "./lib/combat-gate.js";
import { maybeArmDanceHintForWave, onNextFoeForHints, onVictoryForHints, tryCelebrateFirstWaveVictoryHeal, } from "./lib/combat-hints.js";
import { startVictoryCelebration, stopVictoryCelebration, } from "./ui/victory-celebration.js";
import { FOES, } from "./game/data.js";
import { el } from "./game/dom.js";
import { CAMPAIGN_WAVES, STORAGE_KEY, } from "./game/constants.js";
import { gameState } from "./state.js";
export function playNextFoeReveal(primary, secondary) {
    applyFoeColorTheme(foeColorTheme);
    setBattleLines(el.battleText, [primary, secondary]);
    revealBattleLog();
    render();
    playFoeEntrance();
}
export async function transitionToNextWave(previousFoeName, transition, entrance = "gameState.foe", exitAnimPromise, knownDefeatVerb, knownDefeatText) {
    const defeatVerb = transition === "defeat" ? (knownDefeatVerb ?? nextDefeatVerb()) : undefined;
    const fleeWithExitAnim = exitAnimPromise !== undefined;
    const fledId = gameState.foe?.id;
    if (fleeWithExitAnim) {
        logLine(`You run away from ${previousFoeName},`, "gameState.player", "Run", turn, `You run away from ${previousFoeName}.`);
    }
    else if (!(transition === "defeat" && knownDefeatVerb)) {
        const actionText = transition === "flee"
            ? `You run away from ${previousFoeName},`
            : `You ${defeatVerb} ${previousFoeName},`;
        logLine(actionText, "gameState.player", transition === "flee" ? "Run" : "Attack", turn, transition === "flee" ? `You run away from ${previousFoeName}.` : actionText);
    }
    gameState.turn = 1;
    pickNextFoeColor();
    let flashWaveVictoryHealHp = false;
    if (transition === "defeat") {
        const completedWave = gameState.wave;
        const isLevelBandFinaleWave = isLevelBandFinale(completedWave, getCampaignLength());
        if (isLevelBandFinaleWave) {
            await playXpBarFullBeat();
        }
        gameState.wave += 1;
        gameState.waveAttempt = 1;
        const levelBefore = playerLevelForWave(gameState.wave - 1);
        const hpBeforeHeal = gameState.player.hp;
        const maxHpBeforeHeal = gameState.player.maxHp;
        const advanced = advanceFoeQueueAfterVictory(gameState.foeQueue, deferredFoeIds, foeOrder, gameState.wave);
        gameState.foeQueue = advanced.queue;
        gameState.deferredFoeIds = advanced.deferred;
        const playerLevel = syncPlayerForCurrentWave({
            grantMaxHpIncrease: true,
            healToMax: playerLevelForWave(wave) > levelBefore,
        });
        if (playerLevel <= levelBefore) {
            applyWaveVictoryHeal();
        }
        const waveHealFlash = tryCelebrateFirstWaveVictoryHeal(gameState.combatHints, completedWave, hpBeforeHeal, gameState.player.hp);
        gameState.combatHints = waveHealFlash.flags;
        flashWaveVictoryHealHp = waveHealFlash.flashHp;
        gameState.combatHints = onVictoryForHints(combatHints);
        gameState.foe = spawnFoeFromQueue();
        gameState.combatHints = onNextFoeForHints(combatHints, {
            hypeLevel,
            hp: gameState.player.hp,
            maxHp: gameState.player.maxHp,
            wave,
            viaKill: true,
        });
        gameState.foeHypeLevel = 0;
        persist();
        if (playerLevel > levelBefore) {
            render();
            void playLevelUpNotice(playerLevel);
        }
    }
    else if (fledId) {
        gameState.waveAttempt += 1;
        const advanced = advanceFoeQueueAfterFlee(gameState.foeQueue, deferredFoeIds, fledId, foeOrder, gameState.wave);
        gameState.foeQueue = advanced.queue;
        gameState.deferredFoeIds = advanced.deferred;
        gameState.foe = spawnFoeFromQueue();
        gameState.combatHints = onNextFoeForHints(combatHints, {
            hypeLevel,
            hp: gameState.player.hp,
            maxHp: gameState.player.maxHp,
            wave,
            viaKill: false,
        });
        gameState.foeHypeLevel = 0;
        persist();
    }
    logWaveStart();
    if (fleeWithExitAnim) {
        gameState.suppressFoePanelRender = true;
        render();
        await exitAnimPromise;
        gameState.suppressFoePanelRender = false;
        playNextFoeReveal({ text: `You run away from ${previousFoeName},`, kind: "gameState.player" }, { text: `but you run into ${gameState.foe.name}!`, kind: "gameState.foe" });
    }
    else {
        playNextFoeReveal({ text: knownDefeatText ?? `You ${defeatVerb} ${previousFoeName},`, kind: "gameState.player" }, { text: `but ${gameState.foe.name} appears!`, kind: "gameState.foe" });
    }
    if (flashWaveVictoryHealHp) {
        playFirstWaveVictoryHealHpFlash();
    }
    persist();
}
export function rollDamage(max) {
    return randomDamage(max, Math.random);
}
export function rollAndApplyPlayerHeal() {
    const hpBefore = gameState.player.hp;
    const result = applyPlayerHealRoll(hpBefore, gameState.player.maxHp, getHealMax(), Math.random);
    gameState.player.hp = result.hp;
    return { rolled: result.rolled, gained: result.gained, hpBefore };
}
export function showPlayerHealRoll(rolled) {
    showDamagePop("hero", `+${rolled}`, "heal");
    void playHeroHeal();
}
export function nextDefeatVerb() {
    const result = advanceDefeatVerb(defeatVerbIndex, DEFEAT_VERBS);
    gameState.defeatVerbIndex = result.nextIndex;
    return result.verb;
}
export function startWave() {
    gameState.waveAttempt = 1;
    syncPlayerForCurrentWave({ healToMax: gameState.wave === 1 });
    if (gameState.foeQueue.length === 0) {
        gameState.foeQueue = buildInitialFoeQueue(foeOrder);
        gameState.deferredFoeIds = [];
    }
    pickNextFoeColor();
    gameState.foe = spawnFoeFromQueue();
    gameState.foeHypeLevel = 0;
    gameState.combatHints = maybeArmDanceHintForWave(combatHints, wave);
    applyFoeColorTheme(foeColorTheme);
    logWaveStart();
    setBattleLines(el.battleText, [{ text: `${gameState.foe.name} appears!`, kind: "gameState.foe" }]);
    revealBattleLog();
    render();
    playFoeEntrance();
    persist();
}
export function gameOverSummaryText(currentWave, isNewRecord = false) {
    const completedWave = Math.max(0, currentWave - 1);
    const waveText = completedWave === 1 ? "1 gameState.wave" : `${completedWave} waves`;
    const summary = `You beat ${waveText}.`;
    return isNewRecord ? `NEW RECORD! ${summary}` : summary;
}
export function updateRecordsOnGameOver() {
    const save = loadSave();
    const completedWave = Math.max(0, gameState.wave - 1);
    const isNewRecord = completedWave > save.bestWave;
    const bestWave = Math.max(save.bestWave, completedWave);
    const runsPlayed = save.runsPlayed + 1;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(withSaveMeta({
        bestWave,
        runsPlayed,
        playerEmoji: gameState.player.emoji,
        heroName: gameState.player.name,
        heroColorTheme,
        setupActive: false,
        snapshot: getSnapshot(),
    })));
    el.gameOverSummary.textContent = gameOverSummaryText(wave, isNewRecord);
    return isNewRecord;
}
export function updateRecordsOnVictory() {
    const save = loadSave();
    const bestWave = Math.max(save.bestWave, getCampaignLength());
    const runsPlayed = save.runsPlayed + 1;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(withSaveMeta({
        bestWave,
        runsPlayed,
        playerEmoji: gameState.player.emoji,
        heroName: gameState.player.name,
        heroColorTheme,
        setupActive: false,
        snapshot: getSnapshot(),
    })));
    el.gameOverSummary.textContent = `All ${CAMPAIGN_WAVES} waves cleared. Critterwave legend.`;
}
export function endGame() {
    stopVictoryCelebration(el.victoryEmojiLayer);
    applyCombatGateState(blockCombatForScreenEnd(combatGateState()));
    gameState.phase = "gameover";
    clearAllHype();
    logEndTitle("GAME OVER");
    updateRecordsOnGameOver();
    persist();
    render();
}
export function winCampaign() {
    applyCombatGateState(blockCombatForScreenEnd(combatGateState()));
    gameState.phase = "victory";
    clearAllHype();
    logEndTitle(`YOU WIN!`);
    updateRecordsOnVictory();
    startVictoryCelebration(el.victoryEmojiLayer, FOES.map((foe) => gameState.foe.emoji), gameState.player.emoji);
    persist();
    render();
}
export async function winWave(defeatVerb, defeatText) {
    if (!gameState.foe)
        return;
    const defeatedFoe = gameState.foe.name;
    if (gameState.wave >= getCampaignLength()) {
        winCampaign();
        return;
    }
    await transitionToNextWave(defeatedFoe, "defeat", "gameState.foe", undefined, defeatVerb, defeatText);
}
