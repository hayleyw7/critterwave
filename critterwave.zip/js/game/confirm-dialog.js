import { el } from "./game/dom.js";
import { PENDING_CONFIRM_OPTIONS, STORAGE_KEY, } from "./game/constants.js";
import { gameState } from "./state.js";
export function applyConfirmOptions(options) {
    el.confirmTitle.textContent = options.title;
    el.confirmMessage.textContent = options.message;
    el.confirmOk.textContent = options.confirmLabel ?? "Yes";
    el.confirmCancel.textContent = options.cancelLabel ?? "Cancel";
    el.confirmOverlay.classList.toggle("confirm-danger", options.danger ?? false);
    el.confirmOverlay.classList.remove("hidden");
}
export function persistPendingConfirm(kind) {
    const fields = readPersistedFields();
    if (kind) {
        fields.pendingConfirm = kind;
    }
    else {
        delete fields.pendingConfirm;
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(withSaveMeta(fields)));
}
export function presentConfirm(kind, onConfirm) {
    return new Promise((resolve) => {
        applyConfirmOptions(PENDING_CONFIRM_OPTIONS[kind]);
        persistPendingConfirm(kind);
        gameState.confirmResolve = (confirmed) => {
            persistPendingConfirm(null);
            el.confirmOverlay.classList.add("hidden");
            el.confirmOverlay.classList.remove("confirm-danger");
            gameState.confirmResolve = null;
            if (confirmed) {
                onConfirm();
            }
            resolve(confirmed);
        };
        el.confirmCancel.focus();
    });
}
export function closeConfirm(confirmed) {
    const resolve = gameState.confirmResolve;
    if (!resolve) {
        return;
    }
    resolve(confirmed);
}
export function restorePendingConfirmIfNeeded() {
    const kind = loadSave().pendingConfirm;
    if (!kind) {
        return;
    }
    void presentConfirm(kind, () => {
        if (kind === "newRun") {
            applyNewRun();
        }
        else {
            applyClearData();
        }
    });
}
export function isConfirmBackdropTarget(target) {
    if (!(target instanceof Node)) {
        return false;
    }
    return !el.confirmPanel.contains(target);
}
export function dismissConfirmFromBackdrop(event) {
    if (el.confirmOverlay.classList.contains("hidden")) {
        return;
    }
    if (!isConfirmBackdropTarget(event.target)) {
        return;
    }
    if (event instanceof PointerEvent && event.button !== 0) {
        return;
    }
    event.preventDefault();
    closeConfirm(false);
}
export function bindConfirmDialog() {
    el.confirmOk.addEventListener("click", () => {
        closeConfirm(true);
    });
    el.confirmCancel.addEventListener("click", () => {
        closeConfirm(false);
    });
    el.confirmOverlay.addEventListener("click", dismissConfirmFromBackdrop);
    el.confirmOverlay.addEventListener("pointerup", dismissConfirmFromBackdrop);
    document.addEventListener("keydown", (event) => {
        if (el.confirmOverlay.classList.contains("hidden")) {
            return;
        }
        if (event.key === "Escape") {
            event.preventDefault();
            closeConfirm(false);
        }
    });
}
