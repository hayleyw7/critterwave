import { HYPE_MAX, clampHype, } from "./lib/game-logic.js";
import { clampInt, parsePendingConfirm, parseSaveMeta, sanitizeGamePhase, sanitizeHypeLevel, sanitizeIdList, sanitizeSnapshotFoe, sanitizeSnapshotPlayer, sanitizeTurn, sanitizeWave, } from "./lib/save-validation.js";
import { isColorThemeId, } from "./lib/color-themes.js";
import { applyColorMode, parseColorMode, runColorModeTransition, } from "./lib/color-mode.js";
import { createCombatHintsState, combatHintsAfterMidRunRestore, combatHintsForSnapshot, maybeArmDanceHintForWave, } from "./lib/combat-hints.js";
import { FOES_BY_ID, FOE_IDS, HERO_EMOJIS, } from "./game/data.js";
import { el } from "./game/dom.js";
import { CAMPAIGN_WAVES, DEFAULT_HERO_EMOJI, SKIP_EXIT_FLUSH_KEY, STORAGE_KEY, } from "./game/constants.js";
import { gameState } from "./state.js";
export function sanitizeBattleLogHistory(raw) {
    if (!Array.isArray(raw))
        return undefined;
    const entries = [];
    for (const entry of raw.slice(-200)) {
        if (!entry || typeof entry !== "object")
            continue;
        const record = entry;
        const linesRaw = Array.isArray(record.lines) ? record.lines : [];
        const lines = linesRaw
            .map((line) => {
            if (!line || typeof line !== "object")
                return null;
            const lineRecord = line;
            const text = typeof lineRecord.text === "string" ? lineRecord.text : "";
            const kind = lineRecord.kind;
            if (kind !== "info" &&
                kind !== "gameState.player" &&
                kind !== "gameState.foe" &&
                kind !== "win" &&
                kind !== "lose") {
                return null;
            }
            return { text: text.slice(0, 240), kind };
        })
            .filter((line) => !!line);
        const action = record.action;
        const safeAction = action === "Attack" || action === "Heal" || action === "Dance" || action === "Run"
            ? action
            : undefined;
        const wave = clampInt(record.wave, 1, CAMPAIGN_WAVES, 1);
        const attempt = clampInt(record.waveTitle?.attempt, 1, 99, 1);
        const waveTitle = record.waveTitle && typeof record.waveTitle === "object"
            ? { wave, attempt }
            : undefined;
        entries.push({
            title: typeof record.title === "string" ? record.title.slice(0, 80) : undefined,
            waveTitle,
            wave,
            turn: clampInt(record.turn, 1, 99999, 1),
            action: safeAction,
            playerAttack: clampInt(record.playerAttack, 0, 999, 0),
            playerPower: clampInt(record.playerPower, 0, HYPE_MAX, 0),
            foeAttack: typeof record.foeAttack === "number"
                ? clampInt(record.foeAttack, 0, 999, 0)
                : null,
            foePower: typeof record.foePower === "number"
                ? clampInt(record.foePower, 0, HYPE_MAX, 0)
                : null,
            foeColorTheme: typeof record.foeColorTheme === "string" && isColorThemeId(record.foeColorTheme)
                ? record.foeColorTheme
                : "amber",
            lines,
        });
    }
    return entries.length > 0 ? entries : undefined;
}
export function getStorageRaw() {
    return localStorage.getItem(STORAGE_KEY);
}
export function loadSave() {
    try {
        const raw = getStorageRaw();
        if (!raw) {
            return { bestWave: 0, runsPlayed: 0, colorMode: gameState.currentColorMode };
        }
        return parseSaveMeta(JSON.parse(raw), {
            allowedHeroEmojis: HERO_EMOJIS,
            campaignWaves: CAMPAIGN_WAVES,
        });
    }
    catch {
        return { bestWave: 0, runsPlayed: 0, colorMode: gameState.currentColorMode };
    }
}
export function withSaveMeta(fields = {}) {
    const save = loadSave();
    return {
        bestWave: save.bestWave,
        runsPlayed: save.runsPlayed,
        colorMode: gameState.currentColorMode,
        ...fields,
    };
}
export function initColorMode() {
    gameState.currentColorMode = parseColorMode(loadSave().colorMode);
    applyColorMode(currentColorMode);
    updateThemeToggleUi();
    applyHeroColorTheme(heroColorTheme);
    applyFoeColorTheme(foeColorTheme);
}
export function updateThemeToggleUi() {
    const isDark = gameState.currentColorMode === "dark";
    const label = isDark ? "Switch to light mode" : "Switch to dark mode";
    el.themeToggle.setAttribute("aria-pressed", isDark ? "false" : "true");
    el.themeToggle.setAttribute("aria-label", label);
    el.themeToggle.setAttribute("title", label);
    el.themeToggleIcon.textContent = isDark ? "☀" : "☾";
}
export function toggleColorMode() {
    el.footerMore.open = false;
    gameState.currentColorMode = gameState.currentColorMode === "dark" ? "light" : "dark";
    runColorModeTransition(() => {
        applyColorMode(currentColorMode);
        updateThemeToggleUi();
        applyHeroColorTheme(heroColorTheme);
        applyFoeColorTheme(foeColorTheme);
    });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(withSaveMeta(readPersistedFields())));
}
export function readPersistedFields() {
    try {
        const raw = getStorageRaw();
        if (!raw) {
            return {};
        }
        const parsed = JSON.parse(raw);
        const fields = {};
        if (typeof parsed.playerEmoji === "string") {
            fields.playerEmoji = parsed.playerEmoji;
        }
        if (typeof parsed.heroName === "string") {
            fields.heroName = parsed.heroName;
        }
        if (typeof parsed.heroColorTheme === "string") {
            fields.heroColorTheme = parsed.heroColorTheme;
        }
        if (parsed.setupActive === true) {
            fields.setupActive = true;
        }
        if (parsed.snapshot && typeof parsed.snapshot === "object") {
            fields.snapshot = parsed.snapshot;
        }
        const pendingConfirm = parsePendingConfirm(parsed.pendingConfirm);
        if (pendingConfirm) {
            fields.pendingConfirm = pendingConfirm;
        }
        return fields;
    }
    catch {
        return {};
    }
}
export function loadSnapshot() {
    try {
        const raw = getStorageRaw();
        if (!raw)
            return null;
        const parsed = JSON.parse(raw);
        const snap = parsed.snapshot;
        if (!snap)
            return null;
        return normalizeSnapshot(snap);
    }
    catch {
        return null;
    }
}
export function normalizeSnapshot(snap) {
    const wave = sanitizeWave(snap.wave, CAMPAIGN_WAVES);
    const legacyFoe = snap.foe ?? snap.goblin;
    const playerEmoji = typeof snap.player?.emoji === "string" ? snap.player.emoji : DEFAULT_HERO_EMOJI;
    const player = sanitizeSnapshotPlayer(snap.player, wave, HERO_EMOJIS, DEFAULT_HERO_EMOJI, getHeroLabelForEmoji(playerEmoji));
    const foeNormalized = legacyFoe
        ? sanitizeSnapshotFoe(legacyFoe, wave, FOES_BY_ID)
        : null;
    return {
        player,
        foe: foeNormalized,
        turn: sanitizeTurn(snap.turn),
        wave,
        phase: sanitizeGamePhase(snap.phase),
        hypeLevel: sanitizeHypeLevel(snap.hypeLevel),
        foeHypeLevel: sanitizeHypeLevel(snap.foeHypeLevel ?? snap.goblinHypeLevel),
        foeOrderIds: sanitizeIdList(snap.foeOrderIds, FOE_IDS),
        foeColorTheme: snap.foeColorTheme,
        heroColorTheme: snap.heroColorTheme && isHeroColorTheme(snap.heroColorTheme)
            ? snap.heroColorTheme
            : undefined,
        combatHints: createCombatHintsState(snap.combatHints ?? {}),
        foeQueueIds: sanitizeIdList(snap.foeQueueIds, FOE_IDS),
        deferredFoeIds: sanitizeIdList(snap.deferredFoeIds, FOE_IDS),
        battleLogHistory: sanitizeBattleLogHistory(snap.battleLogHistory),
    };
}
export function persistStatsOnly() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(withSaveMeta({
        playerEmoji: gameState.player.emoji,
        heroName: gameState.player.name,
        heroColorTheme,
        setupActive: false,
    })));
}
export function persistSetupDraft() {
    if (el.setupOverlay.classList.contains("hidden")) {
        return;
    }
    const name = readHeroNameFromSetup();
    localStorage.setItem(STORAGE_KEY, JSON.stringify(withSaveMeta({
        playerEmoji: gameState.pendingHeroEmoji,
        heroName: name || undefined,
        heroColorTheme: gameState.pendingHeroColorTheme,
        setupActive: true,
    })));
}
export function persist(snapshot) {
    const preserved = readPersistedFields();
    localStorage.setItem(STORAGE_KEY, JSON.stringify(withSaveMeta({
        ...preserved,
        playerEmoji: gameState.player.emoji,
        heroName: gameState.player.name,
        heroColorTheme,
        setupActive: !el.setupOverlay.classList.contains("hidden"),
        snapshot: snapshot ?? getSnapshot(),
    })));
}
export function isConfirmDialogOpen() {
    return !el.confirmOverlay.classList.contains("hidden");
}
export function shouldFlushSnapshotOnPageExit() {
    try {
        if (sessionStorage.getItem(SKIP_EXIT_FLUSH_KEY) === "1") {
            return false;
        }
    }
    catch {
        /* sessionStorage unavailable */
    }
    if (isConfirmDialogOpen()) {
        return true;
    }
    if (!el.setupOverlay.classList.contains("hidden")) {
        return false;
    }
    if (gameState.phase === "gameover" || gameState.phase === "victory") {
        return true;
    }
    return gameState.phase === "combat" && gameState.foe !== null;
}
/** Keep mid-run state (including teach popups) when the gameState.player refreshes or leaves. */
export function flushSnapshotOnPageExit() {
    if (!shouldFlushSnapshotOnPageExit()) {
        return;
    }
    persist();
}
export function bindPageExitPersist() {
    window.addEventListener("pagehide", flushSnapshotOnPageExit);
    document.addEventListener("visibilitychange", () => {
        if (document.visibilityState === "hidden") {
            flushSnapshotOnPageExit();
        }
    });
}
export function getSnapshot() {
    return {
        player: { ...player },
        foe: gameState.foe ? { ...foe } : null,
        turn,
        wave,
        phase,
        hypeLevel,
        foeHypeLevel,
        foeOrderIds: gameState.foeOrder.map((f) => f.id),
        foeQueueIds: gameState.foeQueue,
        deferredFoeIds,
        foeColorTheme,
        heroColorTheme,
        combatHints: combatHintsForSnapshot(combatHints),
        battleLogHistory: gameState.battleLogHistory.map((entry) => ({
            ...entry,
            lines: entry.lines.map((line) => ({ ...line })),
            waveTitle: entry.waveTitle ? { ...entry.waveTitle } : undefined,
        })),
    };
}
export function applySnapshot(snapshot) {
    Object.assign(player, snapshot.player);
    gameState.foe = snapshot.foe ? { ...snapshot.foe } : null;
    gameState.turn = snapshot.turn;
    gameState.wave = snapshot.wave;
    gameState.waveAttempt = 1;
    gameState.phase = snapshot.phase;
    gameState.hypeLevel = clampHype(snapshot.hypeLevel ?? 0);
    gameState.foeHypeLevel = clampHype(snapshot.foeHypeLevel ?? 0);
    gameState.displayedPlayerHype = gameState.hypeLevel;
    gameState.displayedFoeHype = gameState.foeHypeLevel;
    gameState.suppressTeachFlashesThisRender = true;
    gameState.combatHints = combatHintsAfterMidRunRestore(createCombatHintsState(snapshot.combatHints ?? {}), hypeLevel, gameState.foeHypeLevel);
    gameState.foeOrder = restoreFoeOrder(snapshot.foeOrderIds, snapshot.player.emoji);
    const queueState = restoreFoeQueueState(snapshot, foeOrder);
    gameState.foeQueue = queueState.queue;
    gameState.deferredFoeIds = queueState.deferred;
    if (snapshot.heroColorTheme) {
        applyHeroColorTheme(snapshot.heroColorTheme);
    }
    gameState.foeColorTheme = normalizeFoeColorTheme(snapshot.foeColorTheme);
    gameState.lastFoeColorTheme = gameState.foeColorTheme;
    ensureFoeColorDistinctFromHero();
    applyFoeColorTheme(foeColorTheme);
    gameState.battleLogHistory.splice(0, gameState.battleLogHistory.length, ...(snapshot.battleLogHistory ?? []));
    if (gameState.wave > CAMPAIGN_WAVES) {
        gameState.wave = CAMPAIGN_WAVES;
    }
    syncPlayerForCurrentWave();
    refreshFoeStatsPreservingHp();
    gameState.combatHints = maybeArmDanceHintForWave(combatHints, wave);
}
