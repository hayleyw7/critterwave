import { healHpAfterWaveVictory, hypeHeadroom, } from "./lib/game-logic.js";
import { formatDanceHypeTail, getPlayerHypeGain, getFoeHypeGain, pickRandomDanceOpener, pickRandomDanceResponse, pickFirstDanceResponse, } from "./content/dance-responses.js";
import { beginAwaitingFoeResponse, } from "./lib/combat-gate.js";
import { deferDanceHintAfterRun, recordAttackForHints, recordDanceForHints, recordHealForHints, recordPlayerDamageForHints, recordRunForHints, } from "./lib/combat-hints.js";
import { gameState } from "./state.js";
export function applyFoeCounterAttack() {
    if (!gameState.foe || gameState.foe.hp <= 0)
        return null;
    const hit = rollDamage(getEffectiveFoeAttack());
    gameState.player.hp = Math.max(0, gameState.player.hp - hit);
    if (hit > 0) {
        const damageHint = recordPlayerDamageForHints(combatHints);
        gameState.combatHints = damageHint.flags;
        if (damageHint.flashHp) {
            playFirstPlayerDamageHpFlash();
        }
        applyPlayerHitHypeLoss(hit);
    }
    if (gameState.player.hp > 0) {
        gameState.turn += 1;
    }
    return hit;
}
export function onAttack() {
    const generation = lockCombat();
    if (generation === null)
        return;
    const currentFoe = gameState.foe;
    const actionTurn = gameState.turn;
    const firstAttack = !gameState.combatHints.dismissedAttackHint;
    gameState.combatHints = recordAttackForHints(combatHints);
    syncCombatHintClasses();
    if (firstAttack) {
        playFirstAttackFoeHpFlash();
    }
    const hit = rollDamage(getEffectiveAttack());
    currentFoe.hp = Math.max(0, currentFoe.hp - hit);
    if (hit > 0) {
        applyFoeHitHypeLoss(hit);
    }
    const foeKilled = currentFoe.hp <= 0;
    showDamagePop("gameState.foe", `-${hit}`, "damage");
    playHitExchange("hero", "gameState.foe", foeKilled);
    if (foeKilled) {
        const defeatVerb = nextDefeatVerb();
        const defeatText = `You ${defeatVerb} ${currentFoe.name} with ${hit} damage,`;
        logLine(defeatText, "gameState.player", "Attack", actionTurn, `You ${defeatVerb} ${currentFoe.name} with ${hit} damage.`);
        render();
        const isFinal = gameState.wave >= getCampaignLength();
        void playFoeDefeat(isFinal)
            .then(async () => {
            if (isFinal) {
                applyWaveVictoryHeal();
                await playXpBarFullBeat();
                winCampaign();
            }
            else {
                return winWave(defeatVerb, defeatText);
            }
        })
            .finally(() => finishCombatAction(generation));
        return;
    }
    applyCombatGateState(beginAwaitingFoeResponse(combatGateState()));
    const counterHit = applyFoeCounterAttack();
    syncCombatHintClasses();
    if (counterHit === null) {
        finishCombatAction(generation);
        return;
    }
    logBattleLines({ text: `You hit ${currentFoe.name} for ${hit} damage.`, kind: "gameState.player" }, { text: `${currentFoe.name} hits you for ${counterHit} damage.`, kind: "gameState.foe" }, "Attack", actionTurn);
    render();
    persist();
    scheduleFoeCounterHitVisuals(counterHit, generation);
}
export function applyHealPop(gained) {
    if (gained <= 0) {
        return;
    }
    showDamagePop("hero", `+${gained}`, "heal");
    render();
    void playHeroHeal();
}
export function applyWaveVictoryHealPop(hpBefore) {
    applyHealPop(gameState.player.hp - hpBefore);
}
export function applyFleeHeal() {
    const { rolled, gained } = rollAndApplyPlayerHeal();
    showPlayerHealRoll(rolled);
    if (gained > 0) {
        render();
        persist();
    }
}
export function applyWaveVictoryHeal() {
    const before = gameState.player.hp;
    gameState.player.hp = healHpAfterWaveVictory(before, gameState.player.maxHp);
    applyWaveVictoryHealPop(before);
}
export function onHeal() {
    const generation = lockCombat();
    if (generation === null)
        return;
    const currentFoe = gameState.foe;
    const actionTurn = gameState.turn;
    gameState.skipPlayerHypeTeachThisRender = true;
    const { rolled, gained } = rollAndApplyPlayerHeal();
    const firstMeaningfulHeal = !gameState.combatHints.dismissedHealHint && gained > 0;
    gameState.combatHints = recordHealForHints(combatHints, { armDance: gained > 0 });
    syncCombatHintClasses();
    if (firstMeaningfulHeal) {
        playFirstHealHpFlash();
    }
    showPlayerHealRoll(rolled);
    applyCombatGateState(beginAwaitingFoeResponse(combatGateState()));
    const counterHit = applyFoeCounterAttack();
    syncCombatHintClasses();
    if (counterHit === null) {
        render();
        persist();
        finishCombatAction(generation);
        return;
    }
    logBattleLines({ text: `You healed yourself for ${rolled} HP.`, kind: "gameState.player" }, { text: `${currentFoe.name} hits you for ${counterHit} damage.`, kind: "gameState.foe" }, "Heal", actionTurn);
    render();
    persist();
    scheduleFoeCounterHitVisuals(counterHit, generation);
}
export function onDance() {
    const generation = lockCombat();
    if (generation === null)
        return;
    const currentFoe = gameState.foe;
    const actionTurn = gameState.turn;
    const isFirstDance = !gameState.combatHints.celebratedFirstDance;
    gameState.combatHints = recordDanceForHints(combatHints);
    syncCombatHintClasses();
    const response = isFirstDance
        ? pickFirstDanceResponse()
        : pickRandomDanceResponse();
    const attemptedPlayerGain = getPlayerHypeGain(response);
    const attemptedFoeGain = getFoeHypeGain(response);
    const joins = response.foeJoins === true;
    const actualPlayerGain = Math.min(attemptedPlayerGain, hypeHeadroom(hypeLevel));
    const actualFoeGain = Math.min(attemptedFoeGain, hypeHeadroom(foeHypeLevel));
    const playerCapped = attemptedPlayerGain > 0 && actualPlayerGain < attemptedPlayerGain;
    const foeCapped = attemptedFoeGain > 0 && actualFoeGain < attemptedFoeGain;
    if (actualPlayerGain > 0) {
        applyPlayerDanceBuff(actualPlayerGain);
    }
    if (actualFoeGain > 0) {
        applyFoeDanceBuff(actualFoeGain);
    }
    const opener = pickRandomDanceOpener();
    const reaction = formatFoeInText(response.message);
    const tail = formatDanceHypeTail(actualPlayerGain, actualFoeGain, currentFoe.name, {
        playerCapped,
        foeCapped,
    });
    playHeroDance();
    logDanceLines(opener, reaction, {
        playerGain: actualPlayerGain,
        foeGain: actualFoeGain,
        playerCapped,
        foeCapped,
        turnOverride: actionTurn,
    });
    const foeDances = joins || attemptedFoeGain > 0;
    if (tail) {
        if (actualPlayerGain > 0) {
            showDamagePop("hero", "HYPE", "hype");
        }
    }
    gameState.turn += 1;
    render();
    persist();
    scheduleFoeDanceFollowUp(generation, {
        foeDances,
        foeGain: actualFoeGain,
        foeCapped,
    });
}
export function onRun() {
    const generation = lockCombat();
    if (generation === null)
        return;
    const currentFoe = gameState.foe;
    if (gameState.wave >= getCampaignLength()) {
        logLine("No fleeing the final gameState.foe!", "info", "Run");
        finishCombatAction(generation);
        return;
    }
    gameState.combatHints = deferDanceHintAfterRun(combatHints);
    gameState.combatHints = recordRunForHints(combatHints);
    syncCombatHintClasses();
    clearAllHype();
    applyFleeHeal();
    const fledFoe = currentFoe.name;
    const exitAnimPromise = playRunExit();
    void transitionToNextWave(fledFoe, "flee", "run", exitAnimPromise).finally(() => finishCombatAction(generation));
}
