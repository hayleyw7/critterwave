import { setBattleLines, } from "./lib/battle-log-dom.js";
import { blockCombatForScreenEnd, } from "./lib/combat-gate.js";
import { startVictoryCelebration, } from "./ui/victory-celebration.js";
import { FOES, } from "./game/data.js";
import { el } from "./game/dom.js";
import { CAMPAIGN_WAVES, SKIP_EXIT_FLUSH_KEY, } from "./game/constants.js";
import { gameState } from "./state.js";
export async function beginGame() {
    const save = loadSave();
    if (save.playerEmoji) {
        applyHeroChoice(save.playerEmoji, resolveSavedHeroName(save, save.playerEmoji));
    }
    const snapshot = loadSnapshot();
    if (snapshot && snapshot.phase === "combat" && snapshot.foe) {
        applySnapshot(snapshot);
        if (gameState.battleLogHistory.length === 0) {
            logWaveStart();
        }
        setBattleLines(el.battleText, [
            { text: "Welcome back — your run was restored.", kind: "info" },
            {
                text: `It's your gameState.turn against ${gameState.foe.name}!`,
                kind: "gameState.player",
            },
        ]);
        revealBattleLog();
        render();
        persist();
        return;
    }
    if (snapshot?.phase === "gameover" || snapshot?.phase === "victory") {
        applySnapshot(snapshot);
        applyCombatGateState(blockCombatForScreenEnd(combatGateState()));
        if (snapshot.phase === "victory") {
            if (gameState.battleLogHistory.length === 0) {
                logEndTitle(`Wave ${CAMPAIGN_WAVES} cleared! Total victory!`);
            }
            startVictoryCelebration(el.victoryEmojiLayer, FOES.map((foe) => gameState.foe.emoji), gameState.player.emoji);
            el.gameOverSummary.textContent = `All ${CAMPAIGN_WAVES} waves cleared. Critterwave legend.`;
        }
        else {
            if (gameState.battleLogHistory.length === 0) {
                logEndTitle("GAME OVER");
            }
            el.gameOverSummary.textContent = gameOverSummaryText(snapshot.wave);
        }
        render();
        return;
    }
    resetGame();
}
export function finishBoot() {
    requestAnimationFrame(() => {
        document.body.classList.remove("is-booting");
    });
}
export async function init() {
    try {
        sessionStorage.removeItem(SKIP_EXIT_FLUSH_KEY);
    }
    catch {
        /* sessionStorage unavailable */
    }
    initColorMode();
    updateSetupSubtitle();
    bindConfirmDialog();
    bindHelpDialog();
    bindFooterMoreMenu();
    bindCombatTeachPopupDismissal();
    bindActions();
    bindPageExitPersist();
    bindFooterTeachPopupResize();
    renderRecords();
    restoreHelpDialog();
    const handledDebug = mountDebugHooks();
    if (handledDebug) {
        finishBoot();
        return;
    }
    const save = loadSave();
    if (save.setupActive) {
        showSetup();
        finishBoot();
        restorePendingConfirmIfNeeded();
        maybeRunDebugWin();
        return;
    }
    if (!save.playerEmoji) {
        showSetup();
        finishBoot();
        restorePendingConfirmIfNeeded();
        maybeRunDebugWin();
        return;
    }
    applyHeroChoice(save.playerEmoji, resolveSavedHeroName(save, save.playerEmoji));
    applyHeroColorTheme(resolveHeroColorTheme(save));
    void beginGame();
    finishBoot();
    restorePendingConfirmIfNeeded();
    maybeRunDebugWin();
}
