import { buildFoeOrder as buildFoeOrderForHero, DEFEAT_VERBS, foeColorConflictsWithHero as heroFoeColorConflicts, formatFoeInText as formatFoeMessage, formatSetupBlockerMessage, getSetupBlockers as getSetupBlockersForInput, HYPE_ATTACK_PER_LEVEL, HYPE_MAX, applyPlayerHealRoll, applyHypeGain, hypeAfterTakingHit, applyPlayerStatsForWave, clampHype, formatHypeLabel as formatHypeStatLabel, healHpAfterWaveVictory, hypeHeadroom, isLevelBandFinale, advanceFoeQueueAfterFlee, advanceFoeQueueAfterVictory, buildInitialFoeQueue, buildQueueCycleFromWave, makeFoeFromQueueHead, nextDefeatVerb as advanceDefeatVerb, pickFoeFromOrder, playerLevelForWave, playerStatsForWave, refreshWaveFoeFromTemplate, WAVES_PER_LEVEL, xpProgressForDisplay, xpProgressForWave, xpPercentForDisplay, normalizeHeroName, restoreFoeOrder as restoreFoeOrderForHero, randomDamage, } from "../lib/game-logic.js";
import { formatDanceHypeTail, getPlayerHypeGain, getFoeHypeGain, pickRandomDanceOpener, pickRandomDanceResponse, pickFirstDanceResponse, resetDancePicker, } from "../content/dance-responses.js";
import { appendBattleActionMeta, appendBattleLine, setBattleLines, } from "../lib/battle-log-dom.js";
import { clampInt, isDebugHost, parsePendingConfirm, parseSaveMeta, sanitizeGamePhase, sanitizeHypeLevel, sanitizeIdList, sanitizeSavedHeroName, sanitizeSnapshotFoe, sanitizeSnapshotPlayer, sanitizeTurn, sanitizeWave, } from "../lib/save-validation.js";
import { HERO_PICKER_ORDER, isHeroEmojiHiddenInPicker, isMobileHeroPickerViewport, resolveHeroPickerEmoji, } from "../lib/hero-groups.js";
import { COLOR_THEMES, getColorTheme, colorThemeSurfaces, isColorThemeId, } from "../lib/color-themes.js";
import { applyColorMode, parseColorMode, runColorModeTransition, } from "../lib/color-mode.js";
import { beginAwaitingFoeResponse, blockCombatForScreenEnd, canUseCombatActions as canUseCombatActionsGate, finishCombatAction as finishCombatActionGate, foeFollowUpDelayMs, FOE_FOLLOW_UP_DELAY_MS, isFollowUpTimerStale, resetCombatGate, tryLockCombat as tryLockCombatGate, } from "../lib/combat-gate.js";
import { createCombatHintsState, combatHintsAfterMidRunRestore, combatHintsForSnapshot, attackTeachText, deferDanceHintAfterRun, maybeArmDanceHintForWave, onNextFoeForHints, onVictoryForHints, recordAttackForHints, recordDanceForHints, recordHealForHints, recordPlayerDamageForHints, tryCelebrateFirstFoeHype, tryCelebrateFirstPlayerHype, tryCelebrateFirstWaveVictoryHeal, hypeMaxPresentation, recordRunForHints, shouldShowAttackHint, shouldShowDanceHint, shouldShowDanceTeachCopy, shouldShowHealHint, shouldShowHealTeachCopy, shouldShowRunHint, shouldShowRunTeachCopy, } from "../lib/combat-hints.js";
import { startVictoryCelebration, stopVictoryCelebration, } from "../ui/victory-celebration.js";
import { FOES, FOES_BY_ID, FOE_IDS, HEROES, HERO_EMOJIS, } from "./data.js";
import { el } from "./dom.js";
import { CAMPAIGN_WAVES, DANCE_ANIM_MS, DEATH_BEAT_MS, DEFAULT_HERO_COLOR_THEME, DEFAULT_HERO_EMOJI, DEFAULT_HERO_LABEL, FOE_COLOR_THEMES, FOE_ENTRANCE_MS, FOE_POOF_MS, GOLD_FLASH_MS, HEAL_ANIM_MS, HELP_OPEN_KEY, HP_TEACH_FLASH_MS, HYPE_METER_FLASH_MS, LEVEL_UP_NOTICE_MS, MOBILE_TEACH_LAYOUT_MQ, PENDING_CONFIRM_OPTIONS, SETUP_NAME_TEACH_FLASH_MS, SKIP_EXIT_FLUSH_KEY, STORAGE_KEY, XP_FILL_BEAT_MS, } from "./constants.js";
import { gameState } from "./state.js";
function normalizeFoeColorTheme(theme) {
    if (theme && isColorThemeId(theme)) {
        return theme;
    }
    return "amber";
}
// gameState.currentColorMode → gameState
// gameState.debugInstantTransitions → gameState
function buildFoeOrder(heroEmoji) {
    return buildFoeOrderForHero(FOES, heroEmoji);
}
function restoreFoeQueueState(snapshot, order) {
    if (snapshot.foeQueueIds && snapshot.foeQueueIds.length > 0) {
        return {
            queue: snapshot.foeQueueIds,
            deferred: snapshot.deferredFoeIds ?? [],
        };
    }
    const cycle = buildQueueCycleFromWave(order, snapshot.wave);
    if (snapshot.foe?.id) {
        const idx = cycle.indexOf(snapshot.foe.id);
        if (idx >= 0) {
            return { queue: cycle.slice(idx), deferred: [] };
        }
    }
    return { queue: cycle, deferred: [] };
}
function spawnFoeFromQueue() {
    return makeFoeFromQueueHead(gameState.foeQueue, gameState.foeOrder, gameState.wave);
}
function getCampaignLength() {
    return CAMPAIGN_WAVES;
}
function getHealMax() {
    return playerStatsForWave(wave).healMax;
}
function syncPlayerForCurrentWave(options) {
    const next = applyPlayerStatsForWave(gameState.wave, gameState.player, options);
    gameState.player.hp = next.hp;
    gameState.player.maxHp = next.maxHp;
    gameState.player.attack = next.attack;
    return next.level;
}
function refreshFoeStatsPreservingHp() {
    const currentFoe = gameState.foe;
    if (!currentFoe || gameState.foeOrder.length === 0) {
        return;
    }
    const template = gameState.foeOrder.find((entry) => entry.id === currentFoe.id) ??
        pickFoeFromOrder(gameState.foeOrder, gameState.wave);
    const refreshed = refreshWaveFoeFromTemplate(currentFoe.hp, template, gameState.wave);
    currentFoe.maxHp = refreshed.maxHp;
    currentFoe.attack = refreshed.attack;
    currentFoe.level = refreshed.level;
    currentFoe.hp = refreshed.hp;
}
function restoreFoeOrder(ids, heroEmoji) {
    return restoreFoeOrderForHero(ids, heroEmoji, FOES);
}
// gameState.player → gameState
// gameState.player → gameState
// gameState.player → gameState
// gameState.player → gameState
// gameState.player → gameState
// gameState.player → gameState
// gameState.player → gameState
// gameState.player → gameState
// gameState.player → gameStatelet foe: Enemy | null = null;
// gameState.foe → gameState
// gameState.foe → gameState
// gameState.deferredFoeIds → gameState
// gameState.turn → gameState
// gameState.wave → gameState
// gameState.hypeLevel → gameState
// gameState.foe → gameState
// gameState.phase → gameState
// gameState.combatHints → gameState
// gameState.pendingHeroEmoji → gameState
// gameState.pendingHeroLabel → gameState
// gameState.heroColorTheme → gameState
// gameState.pendingHeroColorTheme → gameState
// gameState.foe → gameState
// gameState.lastFoeColorTheme → gameState
// gameState.defeatVerbIndex → gameState
/** Blocks combat buttons during counters, run, gameState.wave change, death anim, etc. */
// gameState.combatBusy → gameState
// gameState.combatActionGeneration → gameState
/** After attack/heal until gameState.foe counter finishes — one hero strike per gameState.foe response. */
// gameState.awaitingFoeResponse → gameState
/** Keep showing the fleeing gameState.foe until exit poof finishes (run away). */
// gameState.suppressFoePanelRender → gameState
// gameState.displayedPlayerHype → gameState
// gameState.displayedFoeHype → gameState
/** Skip first-HYPE teach on the render beat right after Heal (gain may be lost to counter). */
// gameState.skipPlayerHypeTeachThisRender → gameState
/** Skip HYPE teach pulses on the first render after mid-run restore. */
// gameState.suppressTeachFlashesThisRender → gameState
// gameState.temporarilyClosedTeachPopups → gameState
// gameState.setupHintForced → gameState
// gameState.setupColorPickerBound → gameState
// gameState.wave → gameState
// gameState.battleLogHistory → gameState
function sanitizeBattleLogHistory(raw) {
    if (!Array.isArray(raw))
        return undefined;
    const entries = [];
    for (const entry of raw.slice(-200)) {
        if (!entry || typeof entry !== "object")
            continue;
        const record = entry;
        const linesRaw = Array.isArray(record.lines) ? record.lines : [];
        const lines = linesRaw
            .map((line) => {
            if (!line || typeof line !== "object")
                return null;
            const lineRecord = line;
            const text = typeof lineRecord.text === "string" ? lineRecord.text : "";
            const kind = lineRecord.kind;
            if (kind !== "info" &&
                kind !== "player" &&
                kind !== "foe" &&
                kind !== "win" &&
                kind !== "lose") {
                return null;
            }
            return { text: text.slice(0, 240), kind };
        })
            .filter((line) => !!line);
        const action = record.action;
        const safeAction = action === "Attack" || action === "Heal" || action === "Dance" || action === "Run"
            ? action
            : undefined;
        const wave = clampInt(record.wave, 1, CAMPAIGN_WAVES, 1);
        const attempt = clampInt(record.waveTitle?.attempt, 1, 99, 1);
        const waveTitle = record.waveTitle && typeof record.waveTitle === "object"
            ? { gameState, : .wave, attempt }
            : undefined;
        entries.push({
            title: typeof record.title === "string" ? record.title.slice(0, 80) : undefined,
            waveTitle,
            gameState, : .wave,
            turn: clampInt(record.turn, 1, 99999, 1),
            action: safeAction,
            playerAttack: clampInt(record.playerAttack, 0, 999, 0),
            playerPower: clampInt(record.playerPower, 0, HYPE_MAX, 0),
            foeAttack: typeof record.foeAttack === "number"
                ? clampInt(record.foeAttack, 0, 999, 0)
                : null,
            foePower: typeof record.foePower === "number"
                ? clampInt(record.foePower, 0, HYPE_MAX, 0)
                : null,
            foeColorTheme: typeof record.foeColorTheme === "string" && isColorThemeId(record.foeColorTheme)
                ? record.foeColorTheme
                : "amber",
            lines,
        });
    }
    return entries.length > 0 ? entries : undefined;
}
// gameState.confirmResolve → gameState
function applyConfirmOptions(options) {
    el.confirmTitle.textContent = options.title;
    el.confirmMessage.textContent = options.message;
    el.confirmOk.textContent = options.confirmLabel ?? "Yes";
    el.confirmCancel.textContent = options.cancelLabel ?? "Cancel";
    el.confirmOverlay.classList.toggle("confirm-danger", options.danger ?? false);
    el.confirmOverlay.classList.remove("hidden");
}
function persistPendingConfirm(kind) {
    const fields = readPersistedFields();
    if (kind) {
        fields.pendingConfirm = kind;
    }
    else {
        delete fields.pendingConfirm;
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(withSaveMeta(fields)));
}
function presentConfirm(kind, onConfirm) {
    return new Promise((resolve) => {
        applyConfirmOptions(PENDING_CONFIRM_OPTIONS[kind]);
        persistPendingConfirm(kind);
        gameState.confirmResolve = (confirmed) => {
            persistPendingConfirm(null);
            el.confirmOverlay.classList.add("hidden");
            el.confirmOverlay.classList.remove("confirm-danger");
            gameState.confirmResolve = null;
            if (confirmed) {
                onConfirm();
            }
            resolve(confirmed);
        };
        el.confirmCancel.focus();
    });
}
function closeConfirm(confirmed) {
    const resolve = gameState.confirmResolve;
    if (!resolve) {
        return;
    }
    resolve(confirmed);
}
function restorePendingConfirmIfNeeded() {
    const kind = loadSave().pendingConfirm;
    if (!kind) {
        return;
    }
    void presentConfirm(kind, () => {
        if (kind === "newRun") {
            applyNewRun();
        }
        else {
            applyClearData();
        }
    });
}
function isConfirmBackdropTarget(target) {
    if (!(target instanceof Node)) {
        return false;
    }
    return !el.confirmPanel.contains(target);
}
function dismissConfirmFromBackdrop(event) {
    if (el.confirmOverlay.classList.contains("hidden")) {
        return;
    }
    if (!isConfirmBackdropTarget(event.target)) {
        return;
    }
    if (event instanceof PointerEvent && event.button !== 0) {
        return;
    }
    event.preventDefault();
    closeConfirm(false);
}
function bindConfirmDialog() {
    el.confirmOk.addEventListener("click", () => {
        closeConfirm(true);
    });
    el.confirmCancel.addEventListener("click", () => {
        closeConfirm(false);
    });
    el.confirmOverlay.addEventListener("click", dismissConfirmFromBackdrop);
    el.confirmOverlay.addEventListener("pointerup", dismissConfirmFromBackdrop);
    document.addEventListener("keydown", (event) => {
        if (el.confirmOverlay.classList.contains("hidden")) {
            return;
        }
        if (event.key === "Escape") {
            event.preventDefault();
            closeConfirm(false);
        }
    });
}
function getStorageRaw() {
    return localStorage.getItem(STORAGE_KEY);
}
function loadSave() {
    try {
        const raw = getStorageRaw();
        if (!raw) {
            return { bestWave: 0, runsPlayed: 0, colorMode: gameState.currentColorMode };
        }
        return parseSaveMeta(JSON.parse(raw), {
            allowedHeroEmojis: HERO_EMOJIS,
            campaignWaves: CAMPAIGN_WAVES,
        });
    }
    catch {
        return { bestWave: 0, runsPlayed: 0, colorMode: gameState.currentColorMode };
    }
}
function withSaveMeta(fields = {}) {
    const save = loadSave();
    return {
        bestWave: save.bestWave,
        runsPlayed: save.runsPlayed,
        colorMode: gameState.currentColorMode,
        ...fields,
    };
}
function initColorMode() {
    gameState.currentColorMode = parseColorMode(loadSave().colorMode);
    applyColorMode(currentColorMode);
    updateThemeToggleUi();
    applyHeroColorTheme(heroColorTheme);
    applyFoeColorTheme(foeColorTheme);
}
function updateThemeToggleUi() {
    const isDark = gameState.currentColorMode === "dark";
    const label = isDark ? "Switch to light mode" : "Switch to dark mode";
    el.themeToggle.setAttribute("aria-pressed", isDark ? "false" : "true");
    el.themeToggle.setAttribute("aria-label", label);
    el.themeToggle.setAttribute("title", label);
    el.themeToggleIcon.textContent = isDark ? "☀" : "☾";
}
function toggleColorMode() {
    el.footerMore.open = false;
    gameState.currentColorMode = gameState.currentColorMode === "dark" ? "light" : "dark";
    runColorModeTransition(() => {
        applyColorMode(currentColorMode);
        updateThemeToggleUi();
        applyHeroColorTheme(heroColorTheme);
        applyFoeColorTheme(foeColorTheme);
    });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(withSaveMeta(readPersistedFields())));
}
function readPersistedFields() {
    try {
        const raw = getStorageRaw();
        if (!raw) {
            return {};
        }
        const parsed = JSON.parse(raw);
        const fields = {};
        if (typeof parsed.playerEmoji === "string") {
            fields.playerEmoji = parsed.playerEmoji;
        }
        if (typeof parsed.heroName === "string") {
            fields.heroName = parsed.heroName;
        }
        if (typeof parsed.heroColorTheme === "string") {
            fields.heroColorTheme = parsed.heroColorTheme;
        }
        if (parsed.setupActive === true) {
            fields.setupActive = true;
        }
        if (parsed.snapshot && typeof parsed.snapshot === "object") {
            fields.snapshot = parsed.snapshot;
        }
        const pendingConfirm = parsePendingConfirm(parsed.pendingConfirm);
        if (pendingConfirm) {
            fields.pendingConfirm = pendingConfirm;
        }
        return fields;
    }
    catch {
        return {};
    }
}
function loadSnapshot() {
    try {
        const raw = getStorageRaw();
        if (!raw)
            return null;
        const parsed = JSON.parse(raw);
        const snap = parsed.snapshot;
        if (!snap)
            return null;
        return normalizeSnapshot(snap);
    }
    catch {
        return null;
    }
}
function normalizeSnapshot(snap) {
    const wave = sanitizeWave(snap.wave, CAMPAIGN_WAVES);
    const legacyFoe = snap.foe ?? snap.goblin;
    const playerEmoji = typeof snap.player?.emoji === "string" ? snap.player.emoji : DEFAULT_HERO_EMOJI;
    const player = sanitizeSnapshotPlayer(snap.player, gameState.wave, HERO_EMOJIS, DEFAULT_HERO_EMOJI, getHeroLabelForEmoji(playerEmoji));
    const foeNormalized = legacyFoe
        ? sanitizeSnapshotFoe(legacyFoe, gameState.wave, FOES_BY_ID)
        : null;
    return {
        gameState, : .player,
        foe: foeNormalized,
        turn: sanitizeTurn(snap.turn),
        gameState, : .wave,
        phase: sanitizeGamePhase(snap.phase),
        hypeLevel: sanitizeHypeLevel(snap.hypeLevel),
        foeHypeLevel: sanitizeHypeLevel(snap.foeHypeLevel ?? snap.goblinHypeLevel),
        foeOrderIds: sanitizeIdList(snap.foeOrderIds, FOE_IDS),
        foeColorTheme: snap.foeColorTheme,
        heroColorTheme: snap.heroColorTheme && isHeroColorTheme(snap.heroColorTheme)
            ? snap.heroColorTheme
            : undefined,
        combatHints: createCombatHintsState(snap.combatHints ?? {}),
        foeQueueIds: sanitizeIdList(snap.foeQueueIds, FOE_IDS),
        deferredFoeIds: sanitizeIdList(snap.deferredFoeIds, FOE_IDS),
        battleLogHistory: sanitizeBattleLogHistory(snap.battleLogHistory),
    };
}
function persistStatsOnly() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(withSaveMeta({
        playerEmoji: gameState.player.emoji,
        heroName: gameState.player.name,
        gameState, : .heroColorTheme,
        setupActive: false,
    })));
}
function persistSetupDraft() {
    if (el.setupOverlay.classList.contains("hidden")) {
        return;
    }
    const name = readHeroNameFromSetup();
    localStorage.setItem(STORAGE_KEY, JSON.stringify(withSaveMeta({
        playerEmoji: gameState.pendingHeroEmoji,
        heroName: name || undefined,
        heroColorTheme: gameState.pendingHeroColorTheme,
        setupActive: true,
    })));
}
function persist(snapshot) {
    const preserved = readPersistedFields();
    localStorage.setItem(STORAGE_KEY, JSON.stringify(withSaveMeta({
        ...preserved,
        playerEmoji: gameState.player.emoji,
        heroName: gameState.player.name,
        gameState, : .heroColorTheme,
        setupActive: !el.setupOverlay.classList.contains("hidden"),
        snapshot: snapshot ?? getSnapshot(),
    })));
}
function isConfirmDialogOpen() {
    return !el.confirmOverlay.classList.contains("hidden");
}
function shouldFlushSnapshotOnPageExit() {
    try {
        if (sessionStorage.getItem(SKIP_EXIT_FLUSH_KEY) === "1") {
            return false;
        }
    }
    catch {
        /* sessionStorage unavailable */
    }
    if (isConfirmDialogOpen()) {
        return true;
    }
    if (!el.setupOverlay.classList.contains("hidden")) {
        return false;
    }
    if (gameState.phase === "gameover" || gameState.phase === "victory") {
        return true;
    }
    return gameState.phase === "combat" && gameState.foe !== null;
}
/** Keep mid-run state (including teach popups) when the gameState.player refreshes or leaves. */
function flushSnapshotOnPageExit() {
    if (!shouldFlushSnapshotOnPageExit()) {
        return;
    }
    persist();
}
function bindPageExitPersist() {
    window.addEventListener("pagehide", flushSnapshotOnPageExit);
    document.addEventListener("visibilitychange", () => {
        if (document.visibilityState === "hidden") {
            flushSnapshotOnPageExit();
        }
    });
}
function foeColorConflictsWithHero(theme) {
    return heroFoeColorConflicts(gameState.heroColorTheme, theme);
}
function getAvailableFoeColorThemes(excludeLast) {
    let options = FOE_COLOR_THEMES.filter((theme) => !foeColorConflictsWithHero(theme));
    if (excludeLast && gameState.lastFoeColorTheme !== null) {
        const withoutLast = options.filter((theme) => theme !== gameState.lastFoeColorTheme);
        if (withoutLast.length > 0) {
            options = withoutLast;
        }
    }
    return options;
}
function pickNextFoeColor() {
    let options = getAvailableFoeColorThemes(true);
    if (options.length === 0) {
        options = getAvailableFoeColorThemes(false);
    }
    if (options.length === 0) {
        options = FOE_COLOR_THEMES.filter((theme) => !foeColorConflictsWithHero(theme));
    }
    const picked = options[Math.floor(Math.random() * options.length)] ?? "amber";
    gameState.lastFoeColorTheme = picked;
    gameState.foeColorTheme = picked;
    return picked;
}
function ensureFoeColorDistinctFromHero() {
    if (!foeColorConflictsWithHero(foeColorTheme))
        return;
    pickNextFoeColor();
}
function applyFoeColorTheme(theme) {
    const panel = el.foePanel.querySelector(".enemy-status");
    if (!panel)
        return;
    for (const name of FOE_COLOR_THEMES) {
        panel.classList.remove(`gameState.foe-theme-${name}`);
    }
    panel.classList.add(`gameState.foe-theme-${theme}`);
    const colors = colorThemeSurfaces(getColorTheme(theme), gameState.currentColorMode);
    panel.style.setProperty("--gameState.foe-accent", colors.accent);
    panel.style.setProperty("--gameState.foe-accent-dark", colors.dark);
    panel.style.setProperty("--gameState.foe-panel-bg", colors.panelBg);
    panel.style.setProperty("--gameState.foe-plate-bg", colors.plateBg);
    panel.style.setProperty("--gameState.foe-plate-text", colors.plateText);
    panel.style.setProperty("--gameState.foe-hp-wrap-bg", colors.hpWrapBg);
    panel.style.setProperty("--gameState.foe-divider", colors.divider);
    panel.style.setProperty("--gameState.foe-buff-bg", colors.buffBg);
    applyCardHypeStatColors(panel, "foe", colors);
    el.gameShell.style.setProperty("--gameState.foe-accent", colors.accent);
    el.gameShell.style.setProperty("--gameState.foe-accent-dark", colors.dark);
    el.gameShell.style.setProperty("--battle-gameState.foe-text", gameState.currentColorMode === "dark" ? colors.accent : colors.plateText);
}
function getSnapshot() {
    return {
        player: { ...player },
        foe: gameState.foe ? { ...foe } : null,
        gameState, : .turn,
        gameState, : .wave,
        gameState, : .phase,
        gameState, : .hypeLevel,
        gameState, : .foeHypeLevel,
        foeOrderIds: gameState.foeOrder.map((f) => f.id),
        foeQueueIds: gameState.foeQueue,
        gameState, : .deferredFoeIds,
        gameState, : .foeColorTheme,
        gameState, : .heroColorTheme,
        combatHints: combatHintsForSnapshot(combatHints),
        battleLogHistory: gameState.battleLogHistory.map((entry) => ({
            ...entry,
            lines: entry.lines.map((line) => ({ ...line })),
            waveTitle: entry.waveTitle ? { ...entry.waveTitle } : undefined,
        })),
    };
}
function applySnapshot(snapshot) {
    Object.assign(gameState.player, snapshot.player);
    gameState.foe = snapshot.foe ? { ...snapshot.foe } : null;
    gameState.turn = snapshot.turn;
    gameState.wave = snapshot.wave;
    gameState.waveAttempt = 1;
    gameState.phase = snapshot.phase;
    gameState.hypeLevel = clampHype(snapshot.hypeLevel ?? 0);
    gameState.foeHypeLevel = clampHype(snapshot.foeHypeLevel ?? 0);
    gameState.displayedPlayerHype = gameState.hypeLevel;
    gameState.displayedFoeHype = gameState.foeHypeLevel;
    gameState.suppressTeachFlashesThisRender = true;
    gameState.combatHints = combatHintsAfterMidRunRestore(createCombatHintsState(snapshot.combatHints ?? {}), gameState.hypeLevel, gameState.foeHypeLevel);
    gameState.foeOrder = restoreFoeOrder(snapshot.foeOrderIds, snapshot.player.emoji);
    const queueState = restoreFoeQueueState(snapshot, gameState.foeOrder);
    gameState.foeQueue = queueState.queue;
    gameState.deferredFoeIds = queueState.deferred;
    if (snapshot.heroColorTheme) {
        applyHeroColorTheme(snapshot.heroColorTheme);
    }
    gameState.foeColorTheme = normalizeFoeColorTheme(snapshot.foeColorTheme);
    gameState.lastFoeColorTheme = gameState.foeColorTheme;
    ensureFoeColorDistinctFromHero();
    applyFoeColorTheme(foeColorTheme);
    gameState.battleLogHistory.splice(0, gameState.battleLogHistory.length, ...(snapshot.battleLogHistory ?? []));
    if (gameState.wave > CAMPAIGN_WAVES) {
        gameState.wave = CAMPAIGN_WAVES;
    }
    syncPlayerForCurrentWave();
    refreshFoeStatsPreservingHp();
    gameState.combatHints = maybeArmDanceHintForWave(gameState.combatHints, gameState.wave);
}
function getHeroLabelForEmoji(emoji) {
    return HEROES.find((h) => h.emoji === emoji)?.label ?? DEFAULT_HERO_LABEL;
}
function resolveSavedHeroName(save, emoji) {
    return sanitizeSavedHeroName(save.heroName, save.heroLabel, getHeroLabelForEmoji(emoji));
}
function readHeroNameFromSetup() {
    return normalizeHeroName(el.heroNameInput.value);
}
function isHeroColorTheme(value) {
    return isColorThemeId(value);
}
function getHeroColorThemeDefinition(theme) {
    return getColorTheme(theme);
}
function resolveHeroColorTheme(save) {
    if (save.heroColorTheme && isHeroColorTheme(save.heroColorTheme)) {
        return save.heroColorTheme;
    }
    return DEFAULT_HERO_COLOR_THEME;
}
function applyCardHypeStatColors(panel, varPrefix, colors) {
    panel.style.setProperty(`--${varPrefix}-hype-text`, `color-mix(in srgb, ${colors.accent} 55%, ${colors.dark})`);
}
function applyHeroColorTheme(theme) {
    const colors = colorThemeSurfaces(getColorTheme(theme), gameState.currentColorMode);
    gameState.heroColorTheme = theme;
    el.playerPanel.style.setProperty("--hero", colors.accent);
    el.playerPanel.style.setProperty("--hero-dark", colors.dark);
    el.playerPanel.style.setProperty("--hero-panel-bg", colors.panelBg);
    el.playerPanel.style.setProperty("--hero-plate-bg", colors.plateBg);
    el.playerPanel.style.setProperty("--hero-plate-text", colors.plateText);
    el.playerPanel.style.setProperty("--hero-hp-wrap-bg", colors.hpWrapBg);
    el.playerPanel.style.setProperty("--hero-divider", colors.divider);
    applyCardHypeStatColors(el.playerPanel, "hero", colors);
    el.gameShell.style.setProperty("--hero", colors.accent);
    el.gameShell.style.setProperty("--hero-dark", colors.dark);
    el.gameShell.style.setProperty("--battle-hero-text", gameState.currentColorMode === "dark" ? colors.accent : colors.plateText);
    el.xpFill.style.background = colors.accent;
}
function updateHeroColorTogglePreview() {
    const colors = getHeroColorThemeDefinition(pendingHeroColorTheme);
    const swatch = el.heroColorToggle.querySelector(".setup-color-toggle-swatch");
    swatch?.style.setProperty("--swatch-color", colors.accent);
    el.heroColorToggle.setAttribute("aria-label", `Card color: ${colors.label}`);
}
function openHeroColorPopup() {
    el.heroColorPopup.classList.remove("hidden");
    el.heroColorToggle.setAttribute("aria-expanded", "true");
}
function closeHeroColorPopup() {
    el.heroColorPopup.classList.add("hidden");
    el.heroColorToggle.setAttribute("aria-expanded", "false");
}
function toggleHeroColorPopup() {
    if (el.heroColorPopup.classList.contains("hidden")) {
        openHeroColorPopup();
    }
    else {
        closeHeroColorPopup();
    }
}
function bindSetupColorPicker() {
    if (setupColorPickerBound)
        return;
    gameState.setupColorPickerBound = true;
    el.heroColorToggle.addEventListener("click", (e) => {
        e.stopPropagation();
        toggleHeroColorPopup();
    });
    document.addEventListener("click", (e) => {
        if (el.heroColorPopup.classList.contains("hidden"))
            return;
        const target = e.target;
        if (!el.heroColorPopup.contains(target) &&
            !el.heroColorToggle.contains(target)) {
            closeHeroColorPopup();
        }
    });
}
function readHeroColorThemeFromSetup() {
    return gameState.pendingHeroColorTheme;
}
function syncHeroColorSwatchSelection() {
    for (const btn of el.heroColorSwatches.querySelectorAll(".setup-color-swatch")) {
        btn.classList.toggle("selected", btn.dataset.theme === gameState.pendingHeroColorTheme);
        btn.setAttribute("aria-checked", btn.dataset.theme === gameState.pendingHeroColorTheme ? "true" : "false");
    }
}
function buildHeroColorSwatches() {
    if (!el.heroColorSwatches)
        return;
    el.heroColorSwatches.replaceChildren();
    for (const theme of COLOR_THEMES) {
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "setup-color-swatch";
        btn.dataset.theme = theme.id;
        btn.style.setProperty("--swatch-color", theme.accent);
        btn.setAttribute("role", "radio");
        btn.setAttribute("aria-label", theme.label);
        btn.setAttribute("aria-checked", theme.id === gameState.pendingHeroColorTheme ? "true" : "false");
        if (theme.id === gameState.pendingHeroColorTheme) {
            btn.classList.add("selected");
        }
        btn.addEventListener("click", () => {
            gameState.pendingHeroColorTheme = theme.id;
            applyHeroColorTheme(theme.id);
            syncHeroColorSwatchSelection();
            updateHeroColorTogglePreview();
            closeHeroColorPopup();
            persistSetupDraft();
        });
        el.heroColorSwatches.appendChild(btn);
    }
    updateHeroColorTogglePreview();
}
function getSetupBlockers() {
    return getSetupBlockersForInput(gameState.pendingHeroEmoji, el.heroNameInput.value);
}
function updateSetupStartButton() {
    const blockers = getSetupBlockers();
    const canStart = blockers.length === 0;
    const nameMissing = blockers.includes("enter your name");
    const hintBlockers = blockers.filter((blocker) => blocker !== "enter your name");
    el.setupStartBtn.disabled = false;
    el.setupStartBtn.classList.toggle("cmd-start-ready", canStart);
    el.heroNameInput.classList.toggle("setup-name-input--highlight", gameState.setupHintForced && nameMissing);
    el.heroNameInput.setAttribute("aria-invalid", gameState.setupHintForced && nameMissing ? "true" : "false");
    if (canStart || !gameState.setupHintForced) {
        if (canStart) {
            gameState.setupHintForced = false;
        }
        el.setupHint.hidden = true;
        el.setupHint.textContent = "";
        el.setupHint.classList.remove("setup-hint-error");
        return;
    }
    if (hintBlockers.length === 0) {
        el.setupHint.hidden = true;
        el.setupHint.textContent = "";
        el.setupHint.classList.remove("setup-hint-error");
        return;
    }
    el.setupHint.hidden = false;
    el.setupHint.textContent = formatSetupBlockerMessage(hintBlockers);
    el.setupHint.classList.add("setup-hint-error");
}
function playSetupNameTeachFlash() {
    el.heroNameInput.classList.remove("setup-name-teach-flash");
    void el.heroNameInput.offsetWidth;
    el.heroNameInput.classList.add("setup-name-teach-flash");
    window.setTimeout(() => {
        el.heroNameInput.classList.remove("setup-name-teach-flash");
    }, SETUP_NAME_TEACH_FLASH_MS);
}
function showSetupBlockedHint() {
    gameState.setupHintForced = true;
    updateSetupStartButton();
    if (!readHeroNameFromSetup()) {
        playSetupNameTeachFlash();
        el.heroNameInput.focus();
    }
    else {
        el.heroPicker.focus();
    }
}
function getPlayerHypeBonus() {
    return clampHype(hypeLevel) * HYPE_ATTACK_PER_LEVEL;
}
function getFoeHypeBonus() {
    return clampHype(foeHypeLevel) * HYPE_ATTACK_PER_LEVEL;
}
function getEffectiveAttack() {
    return gameState.player.attack + getPlayerHypeBonus();
}
function getEffectiveFoeAttack() {
    if (!gameState.foe)
        return 0;
    return gameState.foe.attack + getFoeHypeBonus();
}
function applyPlayerDanceBuff(amount = 1) {
    gainPlayerHype(amount);
}
function applyFoeDanceBuff(amount = 1) {
    gainFoeHype(amount);
}
function formatHypeAriaLabel(level) {
    const clamped = clampHype(level);
    return `HYPE ${clamped} of ${HYPE_MAX}`;
}
function clearAllHype() {
    gameState.hypeLevel = 0;
    gameState.foeHypeLevel = 0;
    gameState.displayedPlayerHype = 0;
    gameState.displayedFoeHype = 0;
}
function syncHypeMaxPresentation(wrap, level, side) {
    const previous = side === "player" ? displayedPlayerHype : gameState.displayedFoeHype;
    const pres = hypeMaxPresentation(previous, level);
    wrap.classList.toggle("hype-maxed", pres.atMax);
    if (pres.flashReachedMax && !gameState.suppressTeachFlashesThisRender) {
        wrap.classList.remove("hype-maxed-flash");
        void wrap.offsetWidth;
        wrap.classList.add("hype-maxed-flash");
        window.setTimeout(() => wrap.classList.remove("hype-maxed-flash"), HYPE_METER_FLASH_MS);
    }
    const clamped = clampHype(level);
    if (side === "player") {
        gameState.displayedPlayerHype = clamped;
    }
    else {
        gameState.displayedFoeHype = clamped;
    }
}
function applyPlayerHitHypeLoss(damageDealt) {
    gameState.hypeLevel = hypeAfterTakingHit(gameState.hypeLevel, damageDealt);
}
function applyFoeHitHypeLoss(damageDealt) {
    gameState.foeHypeLevel = hypeAfterTakingHit(gameState.foeHypeLevel, damageDealt);
}
function renderHypeMeter(wrap, statusPanel, bar, fill, label, level, side) {
    const clamped = clampHype(level);
    label.textContent = formatHypeStatLabel(clamped);
    label.setAttribute("aria-label", formatHypeAriaLabel(clamped));
    setHpBar(fill, clamped, HYPE_MAX);
    bar.setAttribute("aria-valuenow", String(clamped));
    bar.setAttribute("aria-valuemax", String(HYPE_MAX));
    statusPanel.classList.toggle("hype-full", clamped >= HYPE_MAX);
    syncHypeMaxPresentation(wrap, level, side);
}
function foeDisplayName() {
    return gameState.foe?.name ?? "foe";
}
function formatFoeInText(template) {
    return formatFoeMessage(template, foeDisplayName());
}
function renderRecords() {
    const save = loadSave();
    el.bestWave.textContent = String(save.bestWave);
    el.runs.textContent = String(save.runsPlayed);
}
function setHpBar(fill, current, max) {
    const pct = max > 0 ? Math.max(0, Math.min(100, (current / max) * 100)) : 0;
    fill.style.width = `${pct}%`;
}
function canBeDefeatedByNextHit(hp, incomingAttack) {
    return hp > 0 && incomingAttack >= hp;
}
function playXpBarFullBeat() {
    if (debugInstantTransitions) {
        const { max } = xpProgressForWave(wave);
        setHpBar(el.xpFill, max, max);
        el.xpText.textContent = "100%";
        el.xpBar.setAttribute("aria-valuenow", String(max));
        el.xpBar.setAttribute("aria-valuemax", String(max));
        return Promise.resolve();
    }
    const { max } = xpProgressForWave(wave);
    setHpBar(el.xpFill, max, max);
    el.xpText.textContent = "100%";
    el.xpBar.setAttribute("aria-valuenow", String(max));
    el.xpBar.setAttribute("aria-valuemax", String(max));
    return pause(XP_FILL_BEAT_MS);
}
function playFirstHypeFlash(wrap) {
    wrap.classList.add("hype-first-dance-flash");
    window.setTimeout(() => {
        wrap.classList.remove("hype-first-dance-flash");
    }, HYPE_METER_FLASH_MS);
}
function gainPlayerHype(amount) {
    if (amount <= 0) {
        return;
    }
    gameState.hypeLevel = applyHypeGain(gameState.hypeLevel, amount);
}
function gainFoeHype(amount) {
    if (amount <= 0) {
        return;
    }
    gameState.foeHypeLevel = applyHypeGain(gameState.foeHypeLevel, amount);
}
function syncFirstHypeFlashes() {
    if (suppressTeachFlashesThisRender) {
        return;
    }
    const skipPlayer = gameState.skipPlayerHypeTeachThisRender;
    gameState.skipPlayerHypeTeachThisRender = false;
    if (!skipPlayer) {
        const player = tryCelebrateFirstPlayerHype(gameState.combatHints, gameState.hypeLevel);
        gameState.combatHints = gameState.player.flags;
        if (gameState.player.flashFirstHype) {
            playFirstHypeFlash(el.playerHypeWrap);
        }
    }
    const foe = tryCelebrateFirstFoeHype(gameState.combatHints, gameState.foeHypeLevel);
    gameState.combatHints = gameState.foe.flags;
    if (gameState.foe.flashFirstHype) {
        playFirstHypeFlash(el.foeHypeWrap);
    }
}
function playHpBarTeachFlash(fill, className) {
    const bar = fill.parentElement;
    if (!bar) {
        return;
    }
    bar.classList.remove(className);
    void bar.offsetWidth;
    bar.classList.add(className);
    window.setTimeout(() => bar.classList.remove(className), HP_TEACH_FLASH_MS);
}
function playFirstHealHpFlash() {
    playHpBarTeachFlash(el.playerHpFill, "hp-first-heal-flash");
}
function playFirstPlayerDamageHpFlash() {
    playHpBarTeachFlash(el.playerHpFill, "hp-first-damage-flash");
}
function playFirstAttackFoeHpFlash() {
    playHpBarTeachFlash(el.foeHpFill, "hp-first-attack-flash");
}
function playFirstWaveVictoryHealHpFlash() {
    playHpBarTeachFlash(el.playerHpFill, "hp-first-gameState.wave-heal-flash");
}
function syncCombatHintClasses() {
    if (!el.healBtn || !el.danceBtn || !el.attackBtn || !el.runBtn) {
        return;
    }
    const hasFoe = gameState.foe !== null;
    const showAttack = shouldShowAttackHint(gameState.combatHints, gameState.phase, hasFoe);
    const showHeal = shouldShowHealHint(gameState.combatHints, gameState.player.hp, gameState.player.maxHp, gameState.phase, hasFoe, gameState.foe?.attack ?? 0, gameState.foeHypeLevel);
    const showRun = gameState.foe !== null &&
        shouldShowRunHint(gameState.combatHints, gameState.player.hp, gameState.foe.attack, gameState.foeHypeLevel, gameState.phase, hasFoe);
    const showDance = shouldShowDanceHint(gameState.combatHints, gameState.player.hp, gameState.player.maxHp, gameState.phase, hasFoe, gameState.hypeLevel, gameState.foe?.attack ?? 0, gameState.foeHypeLevel);
    el.attackBtn.classList.toggle("cmd-hint-flash", showAttack);
    el.healBtn.classList.toggle("cmd-hint-flash", showHeal);
    el.danceBtn.classList.toggle("cmd-hint-flash", showDance);
    el.runBtn.classList.toggle("cmd-hint-flash", showRun);
    el.attackBtn.dataset.combatHint = showAttack ? "on" : "off";
    el.healBtn.dataset.combatHint = showHeal ? "on" : "off";
    el.danceBtn.dataset.combatHint = showDance ? "on" : "off";
    el.runBtn.dataset.combatHint = showRun ? "on" : "off";
    syncCombatTeachPopups(showHeal, showDance, showRun);
}
function clearFooterTeachPopupPosition(popup) {
    popup.style.left = "";
    popup.style.top = "";
    popup.style.right = "";
    popup.style.bottom = "";
    popup.style.transform = "";
    popup.style.maxWidth = "";
    popup.style.removeProperty("--teach-arrow-offset");
    popup.style.removeProperty("--teach-arrow-offset-end");
}
function teachPopupGapPx() {
    const raw = getComputedStyle(el.gameShell).getPropertyValue("--space-2").trim();
    if (raw.endsWith("rem")) {
        const rootPx = parseFloat(getComputedStyle(document.documentElement).fontSize);
        return parseFloat(raw) * rootPx;
    }
    return parseFloat(raw) || 0;
}
function teachPopupArrowPx() {
    const raw = getComputedStyle(document.documentElement)
        .getPropertyValue("--cmd-teach-arrow-size")
        .trim();
    return parseFloat(raw) || 7;
}
function teachPopupMaxWidthForLayout() {
    if (!MOBILE_TEACH_LAYOUT_MQ.matches) {
        return null;
    }
    return `${window.innerWidth * 0.8}px`;
}
function positionFooterTeachPopup(popup, btn) {
    const shell = el.gameShell.getBoundingClientRect();
    const btnRect = btn.getBoundingClientRect();
    const gap = teachPopupGapPx();
    const arrow = teachPopupArrowPx();
    const margin = 8;
    popup.style.position = "fixed";
    popup.style.inset = "auto";
    popup.style.right = "auto";
    popup.style.bottom = "auto";
    popup.style.transform = "none";
    popup.style.margin = "0";
    const layoutMaxWidth = teachPopupMaxWidthForLayout();
    if (layoutMaxWidth) {
        popup.style.maxWidth = layoutMaxWidth;
    }
    else {
        popup.style.maxWidth = "";
    }
    const width = popup.offsetWidth;
    let left;
    if (popup.classList.contains("cmd-teach-popup--align-end")) {
        left = btnRect.right - width;
    }
    else {
        left = btnRect.left;
    }
    left = Math.max(shell.left + margin, Math.min(left, shell.right - width - margin));
    popup.style.left = `${left}px`;
    popup.style.top = `${btnRect.bottom + gap}px`;
    void popup.offsetHeight;
    const popupRect = popup.getBoundingClientRect();
    const arrowTipY = popupRect.top - arrow;
    const nudge = btnRect.bottom - arrowTipY;
    if (Math.abs(nudge) > 0.5) {
        popup.style.top = `${popupRect.top + nudge}px`;
    }
    const viewportMargin = 8;
    const viewportTop = viewportMargin;
    const viewportBottom = window.innerHeight - popup.offsetHeight - viewportMargin;
    const currentTop = parseFloat(popup.style.top || "0");
    popup.style.top = `${Math.min(Math.max(currentTop, viewportTop), viewportBottom)}px`;
    const placed = popup.getBoundingClientRect();
    const btnCenterX = btnRect.left + btnRect.width / 2;
    if (popup.classList.contains("cmd-teach-popup--align-end")) {
        popup.style.setProperty("--teach-arrow-offset-end", `${Math.max(0, placed.right - btnCenterX)}px`);
        popup.style.removeProperty("--teach-arrow-offset");
    }
    else {
        popup.style.setProperty("--teach-arrow-offset", `${Math.max(0, btnCenterX - placed.left)}px`);
        popup.style.removeProperty("--teach-arrow-offset-end");
    }
}
function syncCmdTeachPopup(popup, btn, popupId, show) {
    if (!show) {
        gameState.temporarilyClosedTeachPopups.delete(popupId);
    }
    const visible = show && !gameState.temporarilyClosedTeachPopups.has(popupId);
    popup.classList.toggle("hidden", !visible);
    if (visible) {
        btn.setAttribute("aria-describedby", popupId);
        if (popup.classList.contains("cmd-teach-popup--dock-footer")) {
            requestAnimationFrame(() => {
                positionFooterTeachPopup(popup, btn);
                requestAnimationFrame(() => positionFooterTeachPopup(popup, btn));
            });
        }
    }
    else {
        btn.removeAttribute("aria-describedby");
        if (popup.classList.contains("cmd-teach-popup--dock-footer")) {
            clearFooterTeachPopupPosition(popup);
        }
    }
}
function syncVisibleFooterTeachPopups() {
    if (!el.danceTeachPopup.classList.contains("hidden")) {
        positionFooterTeachPopup(el.danceTeachPopup, el.danceBtn);
    }
    if (!el.runTeachPopup.classList.contains("hidden")) {
        positionFooterTeachPopup(el.runTeachPopup, el.runBtn);
    }
}
// gameState.footerTeachPopupResizeBound → gameState
function bindFooterTeachPopupResize() {
    if (footerTeachPopupResizeBound) {
        return;
    }
    gameState.footerTeachPopupResizeBound = true;
    window.addEventListener("resize", syncVisibleFooterTeachPopups);
    el.gameShell.addEventListener("scroll", syncVisibleFooterTeachPopups);
}
function syncCombatTeachPopups(showHeal, showDance, showRun) {
    const hasFoe = gameState.foe !== null;
    syncCmdTeachPopup(el.healTeachPopup, el.healBtn, "cmd-heal-teach", shouldShowHealTeachCopy(gameState.combatHints, showHeal, gameState.phase, hasFoe));
    syncCmdTeachPopup(el.danceTeachPopup, el.danceBtn, "cmd-dance-teach", shouldShowDanceTeachCopy(gameState.combatHints, showDance, gameState.phase, hasFoe));
    syncCmdTeachPopup(el.runTeachPopup, el.runBtn, "cmd-run-teach", shouldShowRunTeachCopy(gameState.combatHints, showRun, gameState.phase, hasFoe));
}
const COMBAT_TEACH_POPUPS = [
    { id: "cmd-heal-teach", popup: el.healTeachPopup },
    { id: "cmd-dance-teach", popup: el.danceTeachPopup },
    { id: "cmd-run-teach", popup: el.runTeachPopup },
];
function visibleCombatTeachPopups() {
    return COMBAT_TEACH_POPUPS.filter(({ popup }) => !popup.classList.contains("hidden"));
}
function closeVisibleCombatTeachPopups() {
    const visiblePopups = visibleCombatTeachPopups();
    if (visiblePopups.length === 0) {
        return;
    }
    for (const { id } of visiblePopups) {
        gameState.temporarilyClosedTeachPopups.add(id);
    }
    syncCombatHintClasses();
}
function isCombatCommandClick(target) {
    return target instanceof Element && target.closest("#actions [data-action]") !== null;
}
function bindCombatTeachPopupDismissal() {
    document.addEventListener("click", (event) => {
        const visiblePopups = visibleCombatTeachPopups();
        if (visiblePopups.length === 0) {
            return;
        }
        const target = event.target;
        if (target instanceof Node && visiblePopups.some(({ popup }) => popup.contains(target))) {
            return;
        }
        // Hints can appear mid-handler when a command triggers a counter-attack; ignore that click.
        if (isCombatCommandClick(target)) {
            return;
        }
        closeVisibleCombatTeachPopups();
    });
    document.addEventListener("keydown", (event) => {
        if (event.key !== "Escape" || visibleCombatTeachPopups().length === 0) {
            return;
        }
        event.preventDefault();
        closeVisibleCombatTeachPopups();
    });
}
function briefClass(element, className, ms) {
    if (debugInstantTransitions) {
        return;
    }
    element.classList.remove(className);
    void element.offsetWidth;
    element.classList.add(className);
    window.setTimeout(() => element.classList.remove(className), ms);
}
function playStageClass(className, ms) {
    if (debugInstantTransitions) {
        return Promise.resolve();
    }
    return new Promise((resolve) => {
        el.battleStage.classList.remove(className);
        void el.battleStage.offsetWidth;
        el.battleStage.classList.add(className);
        window.setTimeout(() => {
            el.battleStage.classList.remove(className);
            resolve();
        }, ms);
    });
}
function clearCombatAnimations() {
    el.playerPanel.classList.remove("hero-death", "hero-death-knockback", "hero-victory-wobble", "hero-heal", "hero-dance");
    el.foePanel.classList.remove("gameState.foe-poof", "gameState.foe-enter", "gameState.foe-dance", "gameState.foe-sprite-hidden");
    clearHitReact(el.playerPanel);
    clearHitReact(el.foePanel);
    el.battleStage.classList.remove("stage-death-vignette", "stage-flash-gold");
}
function clearHitReact(panel) {
    panel
        .querySelector(".emoji-stack")
        ?.classList.remove("hero-took-hit", "hero-took-hit-fatal", "gameState.foe-took-hit", "gameState.foe-took-hit-fatal", "hero-lunge", "gameState.foe-lunge");
    panel
        .querySelector(".hit-mark")
        ?.classList.remove("hit-mark-active", "hit-mark-active-kill");
}
function playHeroHeal() {
    if (debugInstantTransitions) {
        return Promise.resolve();
    }
    return new Promise((resolve) => {
        el.playerPanel.classList.remove("hero-heal");
        void el.playerPanel.offsetWidth;
        el.playerPanel.classList.add("hero-heal");
        window.setTimeout(() => {
            el.playerPanel.classList.remove("hero-heal");
            resolve();
        }, HEAL_ANIM_MS);
    });
}
function playHeroDance() {
    briefClass(el.playerPanel, "hero-dance", DANCE_ANIM_MS);
}
function playFoeDance() {
    briefClass(el.foePanel, "gameState.foe-dance", DANCE_ANIM_MS);
}
async function playRunExit() {
    await playFoePoof();
}
function playRunEntrance() {
    playFoeEntrance();
}
function playFoeEntrance() {
    if (debugInstantTransitions) {
        return;
    }
    el.foePanel.classList.remove("gameState.foe-sprite-hidden");
    briefClass(el.foePanel, "gameState.foe-enter", FOE_ENTRANCE_MS);
}
function playFoePoof() {
    if (debugInstantTransitions) {
        return Promise.resolve();
    }
    return new Promise((resolve) => {
        el.foePanel.classList.remove("gameState.foe-poof", "gameState.foe-sprite-hidden");
        void el.foePanel.offsetWidth;
        el.foePanel.classList.add("gameState.foe-poof");
        window.setTimeout(() => {
            el.foePanel.classList.remove("gameState.foe-poof");
            el.foePanel.classList.add("gameState.foe-sprite-hidden");
            resolve();
        }, FOE_POOF_MS);
    });
}
async function playFoeDefeat(isFinal) {
    if (debugInstantTransitions) {
        return;
    }
    if (isFinal) {
        await Promise.all([playFoePoof(), playStageClass("stage-flash-gold", GOLD_FLASH_MS)]);
        briefClass(el.playerPanel, "hero-victory-wobble", 450);
        await pause(350);
        return;
    }
    await playFoePoof();
}
async function handlePlayerDeath() {
    await pause(420);
    el.playerPanel.classList.add("hero-death");
    await playStageClass("stage-death-vignette", DEATH_BEAT_MS);
    endGame();
}
function spritePopAnchor(side) {
    const panel = side === "hero" ? el.playerPanel : el.foePanel;
    const stack = panel.querySelector(".sprite-wrap .emoji-stack");
    const layerRect = el.damageLayer.getBoundingClientRect();
    if (!stack || layerRect.width <= 0 || layerRect.height <= 0) {
        const fallbackLeft = side === "hero" ? 22 : 78;
        return { left: `${fallbackLeft}%`, top: "42%" };
    }
    const stackRect = stack.getBoundingClientRect();
    const centerX = ((stackRect.left + stackRect.width / 2 - layerRect.left) / layerRect.width) *
        100;
    const gapAbove = Math.max(32, stackRect.height * 0.78);
    const anchorY = ((stackRect.top - gapAbove - layerRect.top) / layerRect.height) * 100;
    return { left: `${centerX}%`, top: `${anchorY}%` };
}
function showDamagePop(side, text, kind, anchorOverride) {
    const pop = document.createElement("span");
    pop.className =
        kind === "heal"
            ? "damage-pop heal-pop"
            : kind === "hype"
                ? "damage-pop hype-pop"
                : "damage-pop";
    pop.textContent = text;
    const anchor = anchorOverride ?? spritePopAnchor(side);
    pop.style.left = anchor.left;
    pop.style.top = anchor.top;
    el.damageLayer.appendChild(pop);
    void pop.offsetWidth;
    window.setTimeout(() => pop.remove(), 900);
}
function playLevelUpNotice(level) {
    if (debugInstantTransitions) {
        return Promise.resolve();
    }
    return new Promise((resolve) => {
        const pop = document.createElement("span");
        pop.className = "level-up-pop";
        pop.textContent = `Level ${level}`;
        pop.setAttribute("role", "status");
        el.heroLevelUpLayer.setAttribute("aria-hidden", "false");
        el.heroLevelUpLayer.appendChild(pop);
        void pop.offsetWidth;
        window.setTimeout(() => {
            pop.remove();
            el.heroLevelUpLayer.setAttribute("aria-hidden", "true");
            resolve();
        }, LEVEL_UP_NOTICE_MS);
    });
}
function renderHeroSprite() {
    el.playerEmoji.textContent = gameState.player.emoji;
    el.playerEmoji.setAttribute("aria-label", gameState.player.name);
    el.playerName.textContent = gameState.player.name.toUpperCase();
}
function render() {
    renderRecords();
    applyHeroColorTheme(heroColorTheme);
    renderHeroSprite();
    el.waveBanner.textContent = `Wave ${Math.min(gameState.wave, getCampaignLength())} / ${getCampaignLength()}`;
    const inEndScreen = gameState.phase === "gameover" || gameState.phase === "victory";
    el.turnLabel.textContent = inEndScreen ? "-" : String(turn);
    const xp = xpProgressForDisplay(gameState.wave, gameState.phase);
    setHpBar(el.xpFill, xp.current, xp.max);
    el.xpText.textContent = `${xpPercentForDisplay(gameState.wave, gameState.phase)}%`;
    el.xpBar.setAttribute("aria-valuenow", String(xp.current));
    el.xpBar.setAttribute("aria-valuemax", String(xp.max));
    setHpBar(el.playerHpFill, gameState.player.hp, gameState.player.maxHp);
    el.playerHpText.textContent = `${gameState.player.hp}/${gameState.player.maxHp}`;
    el.playerLevel.textContent = String(playerLevelForWave(wave));
    el.playerAttack.textContent = String(getEffectiveAttack());
    renderHypeMeter(el.playerHypeWrap, el.playerStatus, el.playerHypeBar, el.playerHypeFill, el.playerBuff, gameState.hypeLevel, "player");
    const playerHpBar = el.playerPanel.querySelector(".hp-bar");
    playerHpBar?.classList.toggle("hp-low", canBeDefeatedByNextHit(gameState.player.hp, getEffectiveFoeAttack()));
    if (gameState.foe && !gameState.suppressFoePanelRender) {
        applyFoeColorTheme(foeColorTheme);
        el.foeName.textContent = gameState.foe.name.toUpperCase();
        el.foeLevel.textContent = String(gameState.foe.level);
        el.foeAttack.textContent = String(getEffectiveFoeAttack());
        renderHypeMeter(el.foeHypeWrap, el.foeStatus, el.foeHypeBar, el.foeHypeFill, el.foeBuff, gameState.foeHypeLevel, "foe");
        el.foeEmoji.textContent = gameState.foe.emoji;
        el.foeEmoji.setAttribute("aria-label", gameState.foe.name);
        setHpBar(el.foeHpFill, gameState.foe.hp, gameState.foe.maxHp);
        el.foeHpText.textContent = `${gameState.foe.hp}/${gameState.foe.maxHp}`;
        const foeHpBar = el.foePanel.querySelector(".hp-bar");
        foeHpBar?.classList.toggle("hp-low", canBeDefeatedByNextHit(gameState.foe.hp, getEffectiveAttack()));
    }
    else {
        el.foeStatus.classList.remove("hype-full");
    }
    if (gameState.phase !== "victory") {
        stopVictoryCelebration(el.victoryEmojiLayer);
    }
    el.gameOver.classList.toggle("hidden", !inEndScreen);
    el.gameOver.classList.toggle("game-victory", gameState.phase === "victory");
    el.gameOverTag.textContent = gameState.phase === "victory" ? "YOU WIN!" : "GAME OVER";
    el.restartLabel.textContent = gameState.phase === "victory" ? "Play Again?" : "Try Again?";
    el.gameOverLog.open = false;
    renderGameOverBattleLog();
    el.actions.classList.toggle("hidden", inEndScreen);
    syncFirstHypeFlashes();
    syncCombatHintClasses();
    gameState.suppressTeachFlashesThisRender = false;
}
function rememberBattleLogEntry(lines, action, title, turnOverride = gameState.turn) {
    gameState.battleLogHistory.push({
        title,
        waveTitle: title && title.startsWith("WAVE ")
            ? { gameState, : .wave, attempt: gameState.waveAttempt }
            : undefined,
        gameState, : .wave,
        turn: turnOverride,
        action,
        playerAttack: getEffectiveAttack(),
        playerPower: gameState.hypeLevel,
        foeAttack: gameState.foe ? getEffectiveFoeAttack() : null,
        foePower: gameState.foe ? foeHypeLevel : null,
        gameState, : .foeColorTheme,
        lines: lines.map((line) => ({ ...line })),
    });
}
function resetBattleLogHistory() {
    gameState.battleLogHistory.length = 0;
}
function renderGameOverBattleLog() {
    const waveAttemptCounts = new Map();
    for (const entry of gameState.battleLogHistory) {
        if (!entry.waveTitle)
            continue;
        waveAttemptCounts.set(entry.waveTitle.wave, Math.max(waveAttemptCounts.get(entry.waveTitle.wave) ?? 0, entry.waveTitle.attempt));
    }
    el.gameOverBattleLog.replaceChildren();
    for (const entry of gameState.battleLogHistory) {
        const item = document.createElement("li");
        item.className = entry.title
            ? "game-over-log-entry game-over-log-entry-title"
            : "game-over-log-entry";
        const colors = colorThemeSurfaces(getColorTheme(entry.foeColorTheme), gameState.currentColorMode);
        item.style.setProperty("--entry-gameState.foe-text", gameState.currentColorMode === "dark" ? colors.accent : colors.plateText);
        if (entry.title) {
            const meta = document.createElement("div");
            meta.className = "game-over-log-meta";
            if (entry.waveTitle && (waveAttemptCounts.get(entry.waveTitle.wave) ?? 1) > 1) {
                meta.textContent = `WAVE ${entry.waveTitle.wave}.${entry.waveTitle.attempt}`;
            }
            else {
                meta.textContent = entry.title;
            }
            item.appendChild(meta);
            for (const line of entry.lines) {
                appendBattleLine(item, line.text, line.kind);
            }
            el.gameOverBattleLog.appendChild(item);
            continue;
        }
        if (entry.action) {
            appendBattleActionMeta(item, entry.turn, entry.action);
        }
        for (const line of entry.lines) {
            appendBattleLine(item, line.text, line.kind);
        }
        el.gameOverBattleLog.appendChild(item);
    }
}
function logLine(text, kind = "info", action, turnOverride = gameState.turn, historyText = text) {
    rememberBattleLogEntry([{ text: historyText, kind }], action, undefined, turnOverride);
    el.battleText.textContent = text;
    el.battleText.className = `battle-text battle-${kind}`;
    revealBattleLog();
}
function logWaveStart() {
    if (!gameState.foe)
        return;
    const title = `WAVE ${gameState.wave}`;
    const lines = [];
    if ((gameState.wave - 1) % WAVES_PER_LEVEL === 0) {
        lines.push({
            text: `LEVEL ${playerLevelForWave(wave)}: ${gameState.player.maxHp} HP · ATK ${getEffectiveAttack()}`,
            kind: "player",
        });
    }
    lines.push({
        text: `${gameState.foe.name} · ATK ${getEffectiveFoeAttack()} · HP ${gameState.foe.maxHp}`,
        kind: "foe",
    });
    rememberBattleLogEntry(lines, undefined, title);
}
function logEndTitle(text) {
    rememberBattleLogEntry([], undefined, text);
}
function levelUpStatsText() {
    return `LEVEL UP · ATK ${getEffectiveAttack()} · HP ${gameState.player.maxHp}`;
}
function logBattleLines(primary, secondary, action, turnOverride = gameState.turn) {
    rememberBattleLogEntry([primary, secondary], action, undefined, turnOverride);
    setBattleLines(el.battleText, [primary, secondary]);
    revealBattleLog();
}
function appendDanceHypeSuffix(line, suffix) {
    return suffix ? `${line} ${suffix}` : line;
}
function danceHypeSuffix(gain, capped) {
    if (gain > 0) {
        return `+${gain} HYPE`;
    }
    if (capped) {
        return "MAX HYPE";
    }
    return "";
}
function logDanceLines(opener, reaction, opts) {
    const lines = [
        {
            text: appendDanceHypeSuffix(opener, danceHypeSuffix(opts.playerGain, opts.playerCapped)),
            kind: "player",
        },
        {
            text: appendDanceHypeSuffix(reaction, danceHypeSuffix(opts.foeGain, opts.foeCapped)),
            kind: "foe",
        },
    ];
    rememberBattleLogEntry(lines, "Dance", undefined, opts.turnOverride ?? gameState.turn);
    setBattleLines(el.battleText, lines);
    revealBattleLog();
}
function revealBattleLog() {
    el.battleText.closest(".dialog-box")?.scrollIntoView({ block: "nearest", behavior: "smooth" });
}
function pause(ms) {
    return new Promise((resolve) => window.setTimeout(resolve, ms));
}
function combatGateState() {
    return {
        gameState, : .phase,
        gameState, : .combatBusy,
        gameState, : .awaitingFoeResponse,
        gameState, : .combatActionGeneration,
        playerHp: gameState.player.hp,
        hasFoe: gameState.foe !== null,
    };
}
function applyCombatGateState(state) {
    gameState.combatBusy = state.combatBusy;
    gameState.awaitingFoeResponse = state.awaitingFoeResponse;
    gameState.combatActionGeneration = state.combatActionGeneration;
}
function canUseCombatActions() {
    return canUseCombatActionsGate(combatGateState());
}
/** Returns action generation id when locked; null if actions are not allowed. */
function lockCombat() {
    const locked = tryLockCombatGate(combatGateState());
    if (!locked.ok) {
        return null;
    }
    applyCombatGateState(locked.state);
    return locked.generation;
}
function finishCombatAction(generation) {
    applyCombatGateState(finishCombatActionGate(generation, combatGateState()));
    syncCombatHintClasses();
}
function playNextFoeReveal(primary, secondary) {
    applyFoeColorTheme(foeColorTheme);
    setBattleLines(el.battleText, [primary, secondary]);
    revealBattleLog();
    render();
    playFoeEntrance();
}
async function transitionToNextWave(previousFoeName, transition, entrance = "foe", exitAnimPromise, knownDefeatVerb, knownDefeatText) {
    const defeatVerb = transition === "defeat" ? (knownDefeatVerb ?? nextDefeatVerb()) : undefined;
    const fleeWithExitAnim = exitAnimPromise !== undefined;
    const fledId = gameState.foe?.id;
    if (fleeWithExitAnim) {
        logLine(`You run away from ${previousFoeName},`, "player", "Run", gameState.turn, `You run away from ${previousFoeName}.`);
    }
    else if (!(transition === "defeat" && knownDefeatVerb)) {
        const actionText = transition === "flee"
            ? `You run away from ${previousFoeName},`
            : `You ${defeatVerb} ${previousFoeName},`;
        logLine(actionText, "player", transition === "flee" ? "Run" : "Attack", gameState.turn, transition === "flee" ? `You run away from ${previousFoeName}.` : actionText);
    }
    gameState.turn = 1;
    pickNextFoeColor();
    let flashWaveVictoryHealHp = false;
    if (transition === "defeat") {
        const completedWave = gameState.wave;
        const isLevelBandFinaleWave = isLevelBandFinale(completedWave, getCampaignLength());
        if (isLevelBandFinaleWave) {
            await playXpBarFullBeat();
        }
        gameState.wave += 1;
        gameState.waveAttempt = 1;
        const levelBefore = playerLevelForWave(gameState.wave - 1);
        const hpBeforeHeal = gameState.player.hp;
        const maxHpBeforeHeal = gameState.player.maxHp;
        const advanced = advanceFoeQueueAfterVictory(gameState.foeQueue, gameState.deferredFoeIds, gameState.foeOrder, gameState.wave);
        gameState.foeQueue = advanced.queue;
        gameState.deferredFoeIds = advanced.deferred;
        const playerLevel = syncPlayerForCurrentWave({
            grantMaxHpIncrease: true,
            healToMax: playerLevelForWave(wave) > levelBefore,
        });
        if (playerLevel <= levelBefore) {
            applyWaveVictoryHeal();
        }
        const waveHealFlash = tryCelebrateFirstWaveVictoryHeal(gameState.combatHints, completedWave, hpBeforeHeal, gameState.player.hp);
        gameState.combatHints = waveHealFlash.flags;
        flashWaveVictoryHealHp = waveHealFlash.flashHp;
        gameState.combatHints = onVictoryForHints(combatHints);
        gameState.foe = spawnFoeFromQueue();
        gameState.combatHints = onNextFoeForHints(gameState.combatHints, {
            gameState, : .hypeLevel,
            hp: gameState.player.hp,
            maxHp: gameState.player.maxHp,
            gameState, : .wave,
            viaKill: true,
        });
        gameState.foeHypeLevel = 0;
        persist();
        if (playerLevel > levelBefore) {
            render();
            void playLevelUpNotice(playerLevel);
        }
    }
    else if (fledId) {
        gameState.waveAttempt += 1;
        const advanced = advanceFoeQueueAfterFlee(gameState.foeQueue, gameState.deferredFoeIds, fledId, gameState.foeOrder, gameState.wave);
        gameState.foeQueue = advanced.queue;
        gameState.deferredFoeIds = advanced.deferred;
        gameState.foe = spawnFoeFromQueue();
        gameState.combatHints = onNextFoeForHints(gameState.combatHints, {
            gameState, : .hypeLevel,
            hp: gameState.player.hp,
            maxHp: gameState.player.maxHp,
            gameState, : .wave,
            viaKill: false,
        });
        gameState.foeHypeLevel = 0;
        persist();
    }
    logWaveStart();
    if (fleeWithExitAnim) {
        gameState.suppressFoePanelRender = true;
        render();
        await exitAnimPromise;
        gameState.suppressFoePanelRender = false;
        playNextFoeReveal({ text: `You run away from ${previousFoeName},`, kind: "player" }, { text: `but you run into ${gameState.foe.name}!`, kind: "foe" });
    }
    else {
        playNextFoeReveal({ text: knownDefeatText ?? `You ${defeatVerb} ${previousFoeName},`, kind: "player" }, { text: `but ${gameState.foe.name} appears!`, kind: "foe" });
    }
    if (flashWaveVictoryHealHp) {
        playFirstWaveVictoryHealHpFlash();
    }
    persist();
}
function clearLog() {
    resetBattleLogHistory();
    el.battleText.textContent = "What will you do?";
    el.battleText.className = "battle-text battle-info";
}
function rollDamage(max) {
    return randomDamage(max, Math.random);
}
function rollAndApplyPlayerHeal() {
    const hpBefore = gameState.player.hp;
    const result = applyPlayerHealRoll(hpBefore, gameState.player.maxHp, getHealMax(), Math.random);
    gameState.player.hp = result.hp;
    return { rolled: result.rolled, gained: result.gained, hpBefore };
}
function showPlayerHealRoll(rolled) {
    showDamagePop("hero", `+${rolled}`, "heal");
    void playHeroHeal();
}
function nextDefeatVerb() {
    const result = advanceDefeatVerb(gameState.defeatVerbIndex, DEFEAT_VERBS);
    gameState.defeatVerbIndex = result.nextIndex;
    return result.verb;
}
function startWave() {
    gameState.waveAttempt = 1;
    syncPlayerForCurrentWave({ healToMax: gameState.wave === 1 });
    if (gameState.foeQueue.length === 0) {
        gameState.foeQueue = buildInitialFoeQueue(foeOrder);
        gameState.deferredFoeIds = [];
    }
    pickNextFoeColor();
    gameState.foe = spawnFoeFromQueue();
    gameState.foeHypeLevel = 0;
    gameState.combatHints = maybeArmDanceHintForWave(gameState.combatHints, gameState.wave);
    applyFoeColorTheme(foeColorTheme);
    logWaveStart();
    setBattleLines(el.battleText, [{ text: `${gameState.foe.name} appears!`, kind: "foe" }]);
    revealBattleLog();
    render();
    playFoeEntrance();
    persist();
}
function gameOverSummaryText(currentWave, isNewRecord = false) {
    const completedWave = Math.max(0, currentWave - 1);
    const waveText = completedWave === 1 ? "1 gameState.wave" : `${completedWave} waves`;
    const summary = `You beat ${waveText}.`;
    return isNewRecord ? `NEW RECORD! ${summary}` : summary;
}
function updateRecordsOnGameOver() {
    const save = loadSave();
    const completedWave = Math.max(0, gameState.wave - 1);
    const isNewRecord = completedWave > save.bestWave;
    const bestWave = Math.max(save.bestWave, completedWave);
    const runsPlayed = save.runsPlayed + 1;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(withSaveMeta({
        bestWave,
        runsPlayed,
        playerEmoji: gameState.player.emoji,
        heroName: gameState.player.name,
        gameState, : .heroColorTheme,
        setupActive: false,
        snapshot: getSnapshot(),
    })));
    el.gameOverSummary.textContent = gameOverSummaryText(gameState.wave, isNewRecord);
    return isNewRecord;
}
function updateRecordsOnVictory() {
    const save = loadSave();
    const bestWave = Math.max(save.bestWave, getCampaignLength());
    const runsPlayed = save.runsPlayed + 1;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(withSaveMeta({
        bestWave,
        runsPlayed,
        playerEmoji: gameState.player.emoji,
        heroName: gameState.player.name,
        gameState, : .heroColorTheme,
        setupActive: false,
        snapshot: getSnapshot(),
    })));
    el.gameOverSummary.textContent = `All ${CAMPAIGN_WAVES} waves cleared. Critterwave legend.`;
}
function endGame() {
    stopVictoryCelebration(el.victoryEmojiLayer);
    applyCombatGateState(blockCombatForScreenEnd(combatGateState()));
    gameState.phase = "gameover";
    clearAllHype();
    logEndTitle("GAME OVER");
    updateRecordsOnGameOver();
    persist();
    render();
}
function winCampaign() {
    applyCombatGateState(blockCombatForScreenEnd(combatGateState()));
    gameState.phase = "victory";
    clearAllHype();
    logEndTitle(`YOU WIN!`);
    updateRecordsOnVictory();
    startVictoryCelebration(el.victoryEmojiLayer, FOES.map((foe) => gameState.foe.emoji), gameState.player.emoji);
    persist();
    render();
}
function hasDebugWin() {
    return (isDebugHost(window.location.hostname) &&
        new URLSearchParams(window.location.search).get("debug") === "win");
}
function ensureDebugHeroChoice() {
    if (gameState.player.emoji) {
        return;
    }
    const first = HEROES[0];
    applyHeroChoice(first.emoji, first.label);
    applyHeroColorTheme(resolveHeroColorTheme(loadSave()));
}
function waitForDebugTick() {
    return new Promise((resolve) => window.setTimeout(resolve, 0));
}
function performDebugCombatAction(action) {
    switch (action) {
        case "heal":
            onHeal();
            return;
        case "dance":
            onDance();
            return;
        case "run":
            onRun();
            return;
        default:
            onAttack();
    }
}
function scriptedDebugAction(actions, index, campaignLength) {
    if (index >= actions.length) {
        return { action: "attack", nextIndex: index };
    }
    const candidate = actions[index];
    if (candidate === "run" && gameState.wave >= campaignLength) {
        return { action: "attack", nextIndex: index + 1 };
    }
    return { action: candidate, nextIndex: index + 1 };
}
function tuneDebugLoseLogFoe() {
    if (!gameState.foe) {
        return;
    }
    if (gameState.foe.maxHp < 60) {
        gameState.foe.maxHp = 60;
        gameState.foe.hp = Math.max(gameState.foe.hp, 60);
    }
    gameState.foe.attack = Math.max(gameState.foe.attack, 12);
}
function triggerDebugWin() {
    hideSetup();
    ensureDebugHeroChoice();
    gameState.wave = getCampaignLength();
    clearLog();
    winCampaign();
}
async function triggerDebugWinLog() {
    hideSetup();
    ensureDebugHeroChoice();
    gameState.debugInstantTransitions = true;
    try {
        const campaignLength = getCampaignLength();
        const scriptedActions = [
            "dance",
            "heal",
            "attack",
            "run",
            "dance",
            "attack",
            "heal",
            "attack",
        ];
        let scriptedActionIndex = 0;
        resetGame();
        gameState.player.hp = 9999;
        gameState.player.maxHp = 9999;
        gameState.player.attack = 9999;
        render();
        persist();
        while (gameState.phase === "combat") {
            if (!gameState.foe) {
                await waitForDebugTick();
                continue;
            }
            if (!canUseCombatActions()) {
                await waitForDebugTick();
                continue;
            }
            gameState.player.attack = 9999;
            const scripted = scriptedDebugAction(scriptedActions, scriptedActionIndex, campaignLength);
            scriptedActionIndex = scripted.nextIndex;
            let action = scripted.action;
            if (action === "attack" &&
                gameState.wave < campaignLength &&
                gameState.waveAttempt === 1 &&
                gameState.turn === 1) {
                if (gameState.wave % 33 === 0) {
                    action = "run";
                }
                else if (gameState.wave % 19 === 0) {
                    action = "heal";
                }
                else if (gameState.wave % 12 === 0) {
                    action = "dance";
                }
            }
            performDebugCombatAction(action);
            await waitForDebugTick();
        }
    }
    finally {
        gameState.debugInstantTransitions = false;
    }
}
function triggerDebugLose() {
    console.info("[critterwave] debug lose fired");
    hideSetup();
    ensureDebugHeroChoice();
    resetGame();
    gameState.player.hp = 0;
    endGame();
}
async function triggerDebugLoseLog() {
    hideSetup();
    ensureDebugHeroChoice();
    gameState.debugInstantTransitions = true;
    try {
        const campaignLength = getCampaignLength();
        const scriptedActions = [
            "dance",
            "heal",
            "run",
            "dance",
            "heal",
            "attack",
        ];
        let scriptedActionIndex = 0;
        resetGame();
        gameState.player.hp = 40;
        gameState.player.maxHp = 40;
        gameState.player.attack = 1;
        tuneDebugLoseLogFoe();
        render();
        persist();
        while (gameState.phase === "combat") {
            if (!gameState.foe) {
                await waitForDebugTick();
                continue;
            }
            if (!canUseCombatActions()) {
                await waitForDebugTick();
                continue;
            }
            tuneDebugLoseLogFoe();
            const scripted = scriptedDebugAction(scriptedActions, scriptedActionIndex, campaignLength);
            scriptedActionIndex = scripted.nextIndex;
            performDebugCombatAction(scripted.action);
            await waitForDebugTick();
        }
    }
    finally {
        gameState.debugInstantTransitions = false;
    }
}
function mountDebugHooks() {
    if (!isDebugHost(window.location.hostname)) {
        return false;
    }
    const debugMode = new URLSearchParams(window.location.search).get("debug");
    if (debugMode === "lose") {
        triggerDebugLose();
        return true;
    }
    if (debugMode === "lose-log") {
        window.critterwave = {
            win: triggerDebugWin,
            lose: triggerDebugLose,
            winLog: triggerDebugWinLog,
            loseLog: triggerDebugLoseLog,
        };
        window.setTimeout(() => {
            void triggerDebugLoseLog();
        }, 0);
        console.info("[critterwave] Debug: simulated lose log — or load with ?debug=lose-log");
        return true;
    }
    if (debugMode === "win") {
        window.critterwave = {
            win: triggerDebugWin,
            lose: triggerDebugLose,
            winLog: triggerDebugWinLog,
            loseLog: triggerDebugLoseLog,
        };
        console.info("[critterwave] Debug: critterwave.win() / lose() / winLog() / loseLog() — or load with ?debug=win|win-log|lose|lose-log");
        return false;
    }
    if (debugMode === "win-log") {
        window.critterwave = {
            win: triggerDebugWin,
            lose: triggerDebugLose,
            winLog: triggerDebugWinLog,
            loseLog: triggerDebugLoseLog,
        };
        window.setTimeout(() => {
            void triggerDebugWinLog();
        }, 0);
        console.info("[critterwave] Debug: simulated win log — or load with ?debug=win-log");
        return true;
    }
    return false;
}
function maybeRunDebugWin() {
    if (!hasDebugWin()) {
        return;
    }
    triggerDebugWin();
}
async function winWave(defeatVerb, defeatText) {
    if (!gameState.foe)
        return;
    const defeatedFoe = gameState.foe.name;
    if (gameState.wave >= getCampaignLength()) {
        winCampaign();
        return;
    }
    await transitionToNextWave(defeatedFoe, "defeat", "foe", undefined, defeatVerb, defeatText);
}
function playHitExchange(attacker, victim, fatal = false) {
    const attackerPanel = attacker === "hero" ? el.playerPanel : el.foePanel;
    const victimPanel = victim === "hero" ? el.playerPanel : el.foePanel;
    const attackerStack = attackerPanel.querySelector(".emoji-stack");
    const victimStack = victimPanel.querySelector(".emoji-stack");
    const victimMark = victimPanel.querySelector(".hit-mark");
    if (!attackerStack || !victimStack || !victimMark)
        return;
    const ms = fatal ? 450 : 400;
    const lungeClass = attacker === "hero" ? "hero-lunge" : "gameState.foe-lunge";
    const hitClass = victim === "hero"
        ? fatal
            ? "hero-took-hit-fatal"
            : "hero-took-hit"
        : fatal
            ? "gameState.foe-took-hit-fatal"
            : "gameState.foe-took-hit";
    briefClass(attackerStack, lungeClass, ms);
    briefClass(victimStack, hitClass, ms);
    briefClass(victimMark, fatal ? "hit-mark-active-kill" : "hit-mark-active", ms);
}
function applyFoeCounterAttack() {
    if (!gameState.foe || gameState.foe.hp <= 0)
        return null;
    const hit = rollDamage(getEffectiveFoeAttack());
    gameState.player.hp = Math.max(0, gameState.player.hp - hit);
    if (hit > 0) {
        const damageHint = recordPlayerDamageForHints(combatHints);
        gameState.combatHints = damageHint.flags;
        if (damageHint.flashHp) {
            playFirstPlayerDamageHpFlash();
        }
        applyPlayerHitHypeLoss(hit);
    }
    if (gameState.player.hp > 0) {
        gameState.turn += 1;
    }
    return hit;
}
function playFoeCounterHitVisuals(hit, fatal) {
    // Hero's hit react may still be on the gameState.foe stack; clear so gameState.foe-lunge doesn't fight gameState.foe-took-hit.
    clearHitReact(el.foePanel);
    clearHitReact(el.playerPanel);
    showDamagePop("hero", `-${hit}`, "damage");
    playHitExchange("foe", "hero", fatal);
}
function scheduleFoeCounterHitVisuals(hit, generation) {
    const fatal = gameState.player.hp <= 0;
    window.setTimeout(() => {
        if (isFollowUpTimerStale(generation, combatGateState(), gameState.phase)) {
            finishCombatAction(generation);
            return;
        }
        playFoeCounterHitVisuals(hit, fatal);
        if (fatal) {
            void handlePlayerDeath().finally(() => finishCombatAction(generation));
            return;
        }
        finishCombatAction(generation);
    }, FOE_FOLLOW_UP_DELAY_MS);
}
function scheduleFoeDanceFollowUp(generation, opts) {
    const delay = foeFollowUpDelayMs(opts.foeDances);
    window.setTimeout(() => {
        if (isFollowUpTimerStale(generation, combatGateState(), gameState.phase)) {
            finishCombatAction(generation);
            return;
        }
        if (opts.foeDances) {
            playFoeDance();
        }
        if (opts.foeGain > 0) {
            showDamagePop("foe", "HYPE", "hype");
        }
        finishCombatAction(generation);
    }, delay);
}
function onAttack() {
    const generation = lockCombat();
    if (generation === null)
        return;
    const currentFoe = gameState.foe;
    const actionTurn = gameState.turn;
    const firstAttack = !gameState.combatHints.dismissedAttackHint;
    gameState.combatHints = recordAttackForHints(combatHints);
    syncCombatHintClasses();
    if (firstAttack) {
        playFirstAttackFoeHpFlash();
    }
    const hit = rollDamage(getEffectiveAttack());
    currentFoe.hp = Math.max(0, currentFoe.hp - hit);
    if (hit > 0) {
        applyFoeHitHypeLoss(hit);
    }
    const foeKilled = currentFoe.hp <= 0;
    showDamagePop("foe", `-${hit}`, "damage");
    playHitExchange("hero", "foe", foeKilled);
    if (foeKilled) {
        const defeatVerb = nextDefeatVerb();
        const defeatText = `You ${defeatVerb} ${currentFoe.name} with ${hit} damage,`;
        logLine(defeatText, "player", "Attack", actionTurn, `You ${defeatVerb} ${currentFoe.name} with ${hit} damage.`);
        render();
        const isFinal = gameState.wave >= getCampaignLength();
        void playFoeDefeat(isFinal)
            .then(async () => {
            if (isFinal) {
                applyWaveVictoryHeal();
                await playXpBarFullBeat();
                winCampaign();
            }
            else {
                return winWave(defeatVerb, defeatText);
            }
        })
            .finally(() => finishCombatAction(generation));
        return;
    }
    applyCombatGateState(beginAwaitingFoeResponse(combatGateState()));
    const counterHit = applyFoeCounterAttack();
    syncCombatHintClasses();
    if (counterHit === null) {
        finishCombatAction(generation);
        return;
    }
    logBattleLines({ text: `You hit ${currentFoe.name} for ${hit} damage.`, kind: "player" }, { text: `${currentFoe.name} hits you for ${counterHit} damage.`, kind: "foe" }, "Attack", actionTurn);
    render();
    persist();
    scheduleFoeCounterHitVisuals(counterHit, generation);
}
function applyHealPop(gained) {
    if (gained <= 0) {
        return;
    }
    showDamagePop("hero", `+${gained}`, "heal");
    render();
    void playHeroHeal();
}
function applyWaveVictoryHealPop(hpBefore) {
    applyHealPop(gameState.player.hp - hpBefore);
}
function applyFleeHeal() {
    const { rolled, gained } = rollAndApplyPlayerHeal();
    showPlayerHealRoll(rolled);
    if (gained > 0) {
        render();
        persist();
    }
}
function applyWaveVictoryHeal() {
    const before = gameState.player.hp;
    gameState.player.hp = healHpAfterWaveVictory(before, gameState.player.maxHp);
    applyWaveVictoryHealPop(before);
}
function onHeal() {
    const generation = lockCombat();
    if (generation === null)
        return;
    const currentFoe = gameState.foe;
    const actionTurn = gameState.turn;
    gameState.skipPlayerHypeTeachThisRender = true;
    const { rolled, gained } = rollAndApplyPlayerHeal();
    const firstMeaningfulHeal = !gameState.combatHints.dismissedHealHint && gained > 0;
    gameState.combatHints = recordHealForHints(gameState.combatHints, { armDance: gained > 0 });
    syncCombatHintClasses();
    if (firstMeaningfulHeal) {
        playFirstHealHpFlash();
    }
    showPlayerHealRoll(rolled);
    applyCombatGateState(beginAwaitingFoeResponse(combatGateState()));
    const counterHit = applyFoeCounterAttack();
    syncCombatHintClasses();
    if (counterHit === null) {
        render();
        persist();
        finishCombatAction(generation);
        return;
    }
    logBattleLines({ text: `You healed yourself for ${rolled} HP.`, kind: "player" }, { text: `${currentFoe.name} hits you for ${counterHit} damage.`, kind: "foe" }, "Heal", actionTurn);
    render();
    persist();
    scheduleFoeCounterHitVisuals(counterHit, generation);
}
function onDance() {
    const generation = lockCombat();
    if (generation === null)
        return;
    const currentFoe = gameState.foe;
    const actionTurn = gameState.turn;
    const isFirstDance = !gameState.combatHints.celebratedFirstDance;
    gameState.combatHints = recordDanceForHints(combatHints);
    syncCombatHintClasses();
    const response = isFirstDance
        ? pickFirstDanceResponse()
        : pickRandomDanceResponse();
    const attemptedPlayerGain = getPlayerHypeGain(response);
    const attemptedFoeGain = getFoeHypeGain(response);
    const joins = response.foeJoins === true;
    const actualPlayerGain = Math.min(attemptedPlayerGain, hypeHeadroom(hypeLevel));
    const actualFoeGain = Math.min(attemptedFoeGain, hypeHeadroom(foeHypeLevel));
    const playerCapped = attemptedPlayerGain > 0 && actualPlayerGain < attemptedPlayerGain;
    const foeCapped = attemptedFoeGain > 0 && actualFoeGain < attemptedFoeGain;
    if (actualPlayerGain > 0) {
        applyPlayerDanceBuff(actualPlayerGain);
    }
    if (actualFoeGain > 0) {
        applyFoeDanceBuff(actualFoeGain);
    }
    const opener = pickRandomDanceOpener();
    const reaction = formatFoeInText(response.message);
    const tail = formatDanceHypeTail(actualPlayerGain, actualFoeGain, currentFoe.name, {
        playerCapped,
        foeCapped,
    });
    playHeroDance();
    logDanceLines(opener, reaction, {
        playerGain: actualPlayerGain,
        foeGain: actualFoeGain,
        playerCapped,
        foeCapped,
        turnOverride: actionTurn,
    });
    const foeDances = joins || attemptedFoeGain > 0;
    if (tail) {
        if (actualPlayerGain > 0) {
            showDamagePop("hero", "HYPE", "hype");
        }
    }
    gameState.turn += 1;
    render();
    persist();
    scheduleFoeDanceFollowUp(generation, {
        foeDances,
        foeGain: actualFoeGain,
        foeCapped,
    });
}
function onRun() {
    const generation = lockCombat();
    if (generation === null)
        return;
    const currentFoe = gameState.foe;
    if (gameState.wave >= getCampaignLength()) {
        logLine("No fleeing the final gameState.foe!", "info", "Run");
        finishCombatAction(generation);
        return;
    }
    gameState.combatHints = deferDanceHintAfterRun(combatHints);
    gameState.combatHints = recordRunForHints(combatHints);
    syncCombatHintClasses();
    clearAllHype();
    applyFleeHeal();
    const fledFoe = currentFoe.name;
    const exitAnimPromise = playRunExit();
    void transitionToNextWave(fledFoe, "flee", "run", exitAnimPromise).finally(() => finishCombatAction(generation));
}
function applyHeroChoice(emoji, label) {
    gameState.player.emoji = emoji;
    gameState.player.name = label;
    gameState.pendingHeroEmoji = emoji;
    gameState.pendingHeroLabel = label;
}
function resolvePickerHeroEmoji(emoji) {
    return resolveHeroPickerEmoji(emoji, HERO_PICKER_ORDER, isMobileHeroPickerViewport());
}
function buildHeroPicker() {
    el.heroPicker.replaceChildren();
    const grid = document.createElement("div");
    grid.className = "emoji-picker-grid";
    const mobile = isMobileHeroPickerViewport();
    for (const hero of HEROES) {
        if (isHeroEmojiHiddenInPicker(hero.emoji, mobile)) {
            continue;
        }
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "emoji-pick";
        btn.dataset.emoji = hero.emoji;
        btn.dataset.label = hero.label;
        btn.setAttribute("aria-label", hero.label);
        const glyph = document.createElement("span");
        glyph.className = "emoji-pick-glyph";
        glyph.setAttribute("aria-hidden", "true");
        glyph.textContent = hero.emoji;
        btn.appendChild(glyph);
        if (hero.emoji === gameState.pendingHeroEmoji) {
            btn.classList.add("selected");
        }
        btn.addEventListener("click", () => {
            for (const other of el.heroPicker.querySelectorAll(".emoji-pick")) {
                other.classList.remove("selected");
            }
            btn.classList.add("selected");
            gameState.pendingHeroEmoji = hero.emoji;
            gameState.pendingHeroLabel = hero.label;
            updateSetupStartButton();
            persistSetupDraft();
        });
        grid.appendChild(btn);
    }
    el.heroPicker.appendChild(grid);
}
function updateSetupSubtitle() {
    el.setupSubtitle.textContent = attackTeachText(CAMPAIGN_WAVES);
}
function showSetup() {
    const save = loadSave();
    closeHeroColorPopup();
    gameState.pendingHeroEmoji = resolvePickerHeroEmoji(save.playerEmoji ?? gameState.player.emoji);
    gameState.pendingHeroLabel = getHeroLabelForEmoji(pendingHeroEmoji);
    gameState.setupHintForced = false;
    updateSetupSubtitle();
    buildHeroPicker();
    el.heroNameInput.value = save.heroName ?? "";
    gameState.pendingHeroColorTheme = resolveHeroColorTheme(save);
    buildHeroColorSwatches();
    applyHeroColorTheme(pendingHeroColorTheme);
    updateSetupStartButton();
    el.setupOverlay.classList.remove("hidden");
    el.gameShell.classList.add("setup-active");
    persistSetupDraft();
}
function hideSetup() {
    closeHeroColorPopup();
    el.setupOverlay.classList.add("hidden");
    el.gameShell.classList.remove("setup-active");
}
function confirmHeroAndStart() {
    const blockers = getSetupBlockers();
    if (blockers.length > 0) {
        showSetupBlockedHint();
        return false;
    }
    const heroName = readHeroNameFromSetup();
    if (!heroName) {
        showSetupBlockedHint();
        return false;
    }
    applyHeroChoice(gameState.pendingHeroEmoji, heroName);
    applyHeroColorTheme(readHeroColorThemeFromSetup());
    hideSetup();
    persistStatsOnly();
    if (foe) {
        resetGame();
    }
    return true;
}
function resetGame() {
    gameState.turn = 1;
    gameState.wave = 1;
    gameState.defeatVerbIndex = 0;
    gameState.foeOrder = buildFoeOrder(gameState.player.emoji);
    gameState.foeQueue = buildInitialFoeQueue(foeOrder);
    gameState.deferredFoeIds = [];
    syncPlayerForCurrentWave({ healToMax: true });
    clearAllHype();
    gameState.lastFoeColorTheme = null;
    resetDancePicker();
    gameState.combatHints = createCombatHintsState();
    gameState.phase = "combat";
    applyCombatGateState(resetCombatGate(combatGateState()));
    clearCombatAnimations();
    stopVictoryCelebration(el.victoryEmojiLayer);
    el.gameOver.classList.add("hidden");
    clearLog();
    startWave();
}
function applyNewRun() {
    persistStatsOnly();
    gameState.foe = null;
    gameState.phase = "combat";
    stopVictoryCelebration(el.victoryEmojiLayer);
    el.gameOver.classList.add("hidden");
    showSetup();
}
function applyClearData() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(withSaveMeta({ bestWave: 0, runsPlayed: 0 })));
    renderRecords();
    gameState.foe = null;
    gameState.phase = "combat";
    stopVictoryCelebration(el.victoryEmojiLayer);
    el.gameOver.classList.add("hidden");
    showSetup();
}
async function startNewGame() {
    await presentConfirm("newRun", applyNewRun);
}
async function resetStats() {
    await presentConfirm("clearData", applyClearData);
}
function bindActions() {
    el.actions.addEventListener("click", (event) => {
        const target = event.target.closest("[data-action]");
        if (!target)
            return;
        const action = target.dataset.action;
        if (!canUseCombatActions())
            return;
        switch (action) {
            case "attack":
                onAttack();
                break;
            case "heal":
                onHeal();
                break;
            case "dance":
                onDance();
                break;
            case "run":
                onRun();
                break;
        }
        target.blur();
    });
    el.restartBtn.addEventListener("click", () => {
        resetGame();
    });
    el.quitBtn.addEventListener("click", () => {
        void startNewGame();
    });
    el.resetStatsBtn.addEventListener("click", () => {
        void resetStats();
    });
    el.themeToggle.addEventListener("click", () => {
        toggleColorMode();
    });
    el.heroNameInput.addEventListener("input", () => {
        updateSetupStartButton();
        persistSetupDraft();
    });
    bindSetupColorPicker();
    el.setupStartBtn.addEventListener("click", () => {
        if (!confirmHeroAndStart()) {
            return;
        }
        if (!gameState.foe) {
            void beginGame();
        }
        else {
            render();
            persist();
        }
    });
}
function openHelp() {
    el.helpOverlay.classList.remove("hidden");
    try {
        sessionStorage.setItem(HELP_OPEN_KEY, "1");
    }
    catch {
        /* sessionStorage unavailable */
    }
    el.helpClose.focus();
}
function closeHelp() {
    el.helpOverlay.classList.add("hidden");
    try {
        sessionStorage.removeItem(HELP_OPEN_KEY);
    }
    catch {
        /* sessionStorage unavailable */
    }
    el.helpBtn.focus();
}
function restoreHelpDialog() {
    try {
        if (sessionStorage.getItem(HELP_OPEN_KEY) === "1") {
            openHelp();
        }
    }
    catch {
        /* sessionStorage unavailable */
    }
}
function isHelpBackdropTarget(target) {
    if (!(target instanceof Node)) {
        return false;
    }
    return !el.helpPanel.contains(target);
}
function dismissHelpFromBackdrop(event) {
    if (el.helpOverlay.classList.contains("hidden")) {
        return;
    }
    if (!isHelpBackdropTarget(event.target)) {
        return;
    }
    if (event instanceof PointerEvent && event.button !== 0) {
        return;
    }
    event.preventDefault();
    closeHelp();
}
function bindHelpDialog() {
    el.helpBtn.addEventListener("click", openHelp);
    el.helpClose.addEventListener("click", closeHelp);
    el.helpOverlay.addEventListener("click", dismissHelpFromBackdrop);
    el.helpOverlay.addEventListener("pointerup", dismissHelpFromBackdrop);
    document.addEventListener("keydown", (event) => {
        if (el.helpOverlay.classList.contains("hidden")) {
            return;
        }
        if (event.key === "Escape") {
            event.preventDefault();
            closeHelp();
        }
    });
}
function closeFooterMore() {
    el.footerMore.open = false;
}
function bindFooterMoreMenu() {
    document.addEventListener("click", (event) => {
        if (!el.footerMore.open) {
            return;
        }
        const target = event.target;
        if (target instanceof Node && el.footerMore.contains(target)) {
            return;
        }
        closeFooterMore();
    });
    document.addEventListener("keydown", (event) => {
        if (!el.footerMore.open) {
            return;
        }
        if (event.key === "Escape") {
            event.preventDefault();
            closeFooterMore();
        }
    });
}
async function beginGame() {
    const save = loadSave();
    if (save.playerEmoji) {
        applyHeroChoice(save.playerEmoji, resolveSavedHeroName(save, save.playerEmoji));
    }
    const snapshot = loadSnapshot();
    if (snapshot && snapshot.phase === "combat" && snapshot.foe) {
        applySnapshot(snapshot);
        if (gameState.battleLogHistory.length === 0) {
            logWaveStart();
        }
        setBattleLines(el.battleText, [
            { text: "Welcome back — your run was restored.", kind: "info" },
            {
                text: `It's your gameState.turn against ${gameState.foe.name}!`,
                kind: "player",
            },
        ]);
        revealBattleLog();
        render();
        persist();
        return;
    }
    if (snapshot?.phase === "gameover" || snapshot?.phase === "victory") {
        applySnapshot(snapshot);
        applyCombatGateState(blockCombatForScreenEnd(combatGateState()));
        if (snapshot.phase === "victory") {
            if (gameState.battleLogHistory.length === 0) {
                logEndTitle(`Wave ${CAMPAIGN_WAVES} cleared! Total victory!`);
            }
            startVictoryCelebration(el.victoryEmojiLayer, FOES.map((foe) => gameState.foe.emoji), gameState.player.emoji);
            el.gameOverSummary.textContent = `All ${CAMPAIGN_WAVES} waves cleared. Critterwave legend.`;
        }
        else {
            if (gameState.battleLogHistory.length === 0) {
                logEndTitle("GAME OVER");
            }
            el.gameOverSummary.textContent = gameOverSummaryText(snapshot.wave);
        }
        render();
        return;
    }
    resetGame();
}
function finishBoot() {
    requestAnimationFrame(() => {
        document.body.classList.remove("is-booting");
    });
}
async function init() {
    try {
        sessionStorage.removeItem(SKIP_EXIT_FLUSH_KEY);
    }
    catch {
        /* sessionStorage unavailable */
    }
    initColorMode();
    updateSetupSubtitle();
    bindConfirmDialog();
    bindHelpDialog();
    bindFooterMoreMenu();
    bindCombatTeachPopupDismissal();
    bindActions();
    bindPageExitPersist();
    bindFooterTeachPopupResize();
    renderRecords();
    restoreHelpDialog();
    const handledDebug = mountDebugHooks();
    if (handledDebug) {
        finishBoot();
        return;
    }
    const save = loadSave();
    if (save.setupActive) {
        showSetup();
        finishBoot();
        restorePendingConfirmIfNeeded();
        maybeRunDebugWin();
        return;
    }
    if (!save.playerEmoji) {
        showSetup();
        finishBoot();
        restorePendingConfirmIfNeeded();
        maybeRunDebugWin();
        return;
    }
    applyHeroChoice(save.playerEmoji, resolveSavedHeroName(save, save.playerEmoji));
    applyHeroColorTheme(resolveHeroColorTheme(save));
    void beginGame();
    finishBoot();
    restorePendingConfirmIfNeeded();
    maybeRunDebugWin();
}
void init();
