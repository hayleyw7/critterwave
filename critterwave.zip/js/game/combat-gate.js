import { gameState } from "./state.js";
function combatGateState() {
    return {
        gameState, : .phase,
        gameState, : .combatBusy,
        gameState, : .awaitingFoeResponse,
        gameState, : .combatActionGeneration,
        playerHp: gameState.player.hp,
        hasFoe: gameState.foe !== null,
    };
}
function applyCombatGateState(state) {
    gameState.combatBusy = state.gameState.combatBusy;
    gameState.awaitingFoeResponse = state.gameState.awaitingFoeResponse;
    gameState.combatActionGeneration = state.gameState.combatActionGeneration;
}
function canUseCombatActions() {
    return canUseCombatActionsGate(combatGateState());
}
/** Returns action generation id when locked; null if actions are not allowed. */
function lockCombat() {
    const locked = tryLockCombatGate(combatGateState());
    if (!locked.ok) {
        return null;
    }
    applyCombatGateState(locked.state);
    return locked.generation;
}
function finishCombatAction(generation) {
    applyCombatGateState(finishCombatActionGate(generation, combatGateState()));
    syncCombatHintClasses();
}
export { combatGateState, applyCombatGateState, canUseCombatActions, lockCombat, finishCombatAction, };
