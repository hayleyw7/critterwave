import { isDebugHost, } from "./lib/save-validation.js";
import { HEROES, } from "./game/data.js";
import { gameState } from "./state.js";
export function hasDebugWin() {
    return (isDebugHost(window.location.hostname) &&
        new URLSearchParams(window.location.search).get("debug") === "win");
}
export function ensureDebugHeroChoice() {
    if (gameState.player.emoji) {
        return;
    }
    const first = HEROES[0];
    applyHeroChoice(first.emoji, first.label);
    applyHeroColorTheme(resolveHeroColorTheme(loadSave()));
}
export function waitForDebugTick() {
    return new Promise((resolve) => window.setTimeout(resolve, 0));
}
export function performDebugCombatAction(action) {
    switch (action) {
        case "heal":
            onHeal();
            return;
        case "dance":
            onDance();
            return;
        case "run":
            onRun();
            return;
        default:
            onAttack();
    }
}
export function scriptedDebugAction(actions, index, campaignLength) {
    if (index >= actions.length) {
        return { action: "attack", nextIndex: index };
    }
    const candidate = actions[index];
    if (candidate === "run" && gameState.wave >= campaignLength) {
        return { action: "attack", nextIndex: index + 1 };
    }
    return { action: candidate, nextIndex: index + 1 };
}
export function tuneDebugLoseLogFoe() {
    if (!gameState.foe) {
        return;
    }
    if (gameState.foe.maxHp < 60) {
        gameState.foe.maxHp = 60;
        gameState.foe.hp = Math.max(gameState.foe.hp, 60);
    }
    gameState.foe.attack = Math.max(gameState.foe.attack, 12);
}
export function triggerDebugWin() {
    hideSetup();
    ensureDebugHeroChoice();
    gameState.wave = getCampaignLength();
    clearLog();
    winCampaign();
}
export async function triggerDebugWinLog() {
    hideSetup();
    ensureDebugHeroChoice();
    gameState.debugInstantTransitions = true;
    try {
        const campaignLength = getCampaignLength();
        const scriptedActions = [
            "dance",
            "heal",
            "attack",
            "run",
            "dance",
            "attack",
            "heal",
            "attack",
        ];
        let scriptedActionIndex = 0;
        resetGame();
        gameState.player.hp = 9999;
        gameState.player.maxHp = 9999;
        gameState.player.attack = 9999;
        render();
        persist();
        while (gameState.phase === "combat") {
            if (!gameState.foe) {
                await waitForDebugTick();
                continue;
            }
            if (!canUseCombatActions()) {
                await waitForDebugTick();
                continue;
            }
            gameState.player.attack = 9999;
            const scripted = scriptedDebugAction(scriptedActions, scriptedActionIndex, campaignLength);
            scriptedActionIndex = scripted.nextIndex;
            let action = scripted.action;
            if (action === "attack" &&
                gameState.wave < campaignLength &&
                gameState.waveAttempt === 1 &&
                gameState.turn === 1) {
                if (gameState.wave % 33 === 0) {
                    action = "run";
                }
                else if (gameState.wave % 19 === 0) {
                    action = "heal";
                }
                else if (gameState.wave % 12 === 0) {
                    action = "dance";
                }
            }
            performDebugCombatAction(action);
            await waitForDebugTick();
        }
    }
    finally {
        gameState.debugInstantTransitions = false;
    }
}
export function triggerDebugLose() {
    console.info("[critterwave] debug lose fired");
    hideSetup();
    ensureDebugHeroChoice();
    resetGame();
    gameState.player.hp = 0;
    endGame();
}
export async function triggerDebugLoseLog() {
    hideSetup();
    ensureDebugHeroChoice();
    gameState.debugInstantTransitions = true;
    try {
        const campaignLength = getCampaignLength();
        const scriptedActions = [
            "dance",
            "heal",
            "run",
            "dance",
            "heal",
            "attack",
        ];
        let scriptedActionIndex = 0;
        resetGame();
        gameState.player.hp = 40;
        gameState.player.maxHp = 40;
        gameState.player.attack = 1;
        tuneDebugLoseLogFoe();
        render();
        persist();
        while (gameState.phase === "combat") {
            if (!gameState.foe) {
                await waitForDebugTick();
                continue;
            }
            if (!canUseCombatActions()) {
                await waitForDebugTick();
                continue;
            }
            tuneDebugLoseLogFoe();
            const scripted = scriptedDebugAction(scriptedActions, scriptedActionIndex, campaignLength);
            scriptedActionIndex = scripted.nextIndex;
            performDebugCombatAction(scripted.action);
            await waitForDebugTick();
        }
    }
    finally {
        gameState.debugInstantTransitions = false;
    }
}
export function mountDebugHooks() {
    if (!isDebugHost(window.location.hostname)) {
        return false;
    }
    const debugMode = new URLSearchParams(window.location.search).get("debug");
    if (debugMode === "lose") {
        triggerDebugLose();
        return true;
    }
    if (debugMode === "lose-log") {
        window.critterwave = {
            win: triggerDebugWin,
            lose: triggerDebugLose,
            winLog: triggerDebugWinLog,
            loseLog: triggerDebugLoseLog,
        };
        window.setTimeout(() => {
            void triggerDebugLoseLog();
        }, 0);
        console.info("[critterwave] Debug: simulated lose log — or load with ?debug=lose-log");
        return true;
    }
    if (debugMode === "win") {
        window.critterwave = {
            win: triggerDebugWin,
            lose: triggerDebugLose,
            winLog: triggerDebugWinLog,
            loseLog: triggerDebugLoseLog,
        };
        console.info("[critterwave] Debug: critterwave.win() / lose() / winLog() / loseLog() — or load with ?debug=win|win-log|lose|lose-log");
        return false;
    }
    if (debugMode === "win-log") {
        window.critterwave = {
            win: triggerDebugWin,
            lose: triggerDebugLose,
            winLog: triggerDebugWinLog,
            loseLog: triggerDebugLoseLog,
        };
        window.setTimeout(() => {
            void triggerDebugWinLog();
        }, 0);
        console.info("[critterwave] Debug: simulated win log — or load with ?debug=win-log");
        return true;
    }
    return false;
}
export function maybeRunDebugWin() {
    if (!hasDebugWin()) {
        return;
    }
    triggerDebugWin();
}
