import { buildFoeOrder as buildFoeOrderForHero, applyPlayerStatsForWave, buildQueueCycleFromWave, makeFoeFromQueueHead, pickFoeFromOrder, playerStatsForWave, refreshWaveFoeFromTemplate, restoreFoeOrder as restoreFoeOrderForHero, } from "./lib/game-logic.js";
import { isColorThemeId, } from "./lib/color-themes.js";
import { FOES, } from "./game/data.js";
import { CAMPAIGN_WAVES, } from "./game/constants.js";
import { gameState } from "./state.js";
export function normalizeFoeColorTheme(theme) {
    if (theme && isColorThemeId(theme)) {
        return theme;
    }
    return "amber";
}
export function buildFoeOrder(heroEmoji) {
    return buildFoeOrderForHero(FOES, heroEmoji);
}
export function restoreFoeQueueState(snapshot, order) {
    if (snapshot.foeQueueIds && snapshot.foeQueueIds.length > 0) {
        return {
            queue: snapshot.foeQueueIds,
            deferred: snapshot.deferredFoeIds ?? [],
        };
    }
    const cycle = buildQueueCycleFromWave(order, snapshot.wave);
    if (snapshot.foe?.id) {
        const idx = cycle.indexOf(snapshot.foe.id);
        if (idx >= 0) {
            return { queue: cycle.slice(idx), deferred: [] };
        }
    }
    return { queue: cycle, deferred: [] };
}
export function spawnFoeFromQueue() {
    return makeFoeFromQueueHead(foeQueue, foeOrder, wave);
}
export function getCampaignLength() {
    return CAMPAIGN_WAVES;
}
export function getHealMax() {
    return playerStatsForWave(wave).healMax;
}
export function syncPlayerForCurrentWave(options) {
    const next = applyPlayerStatsForWave(wave, player, options);
    gameState.player.hp = next.hp;
    gameState.player.maxHp = next.maxHp;
    gameState.player.attack = next.attack;
    return next.level;
}
export function refreshFoeStatsPreservingHp() {
    const currentFoe = gameState.foe;
    if (!currentFoe || gameState.foeOrder.length === 0) {
        return;
    }
    const template = gameState.foeOrder.find((entry) => entry.id === currentFoe.id) ??
        pickFoeFromOrder(foeOrder, wave);
    const refreshed = refreshWaveFoeFromTemplate(currentFoe.hp, template, wave);
    currentFoe.maxHp = refreshed.maxHp;
    currentFoe.attack = refreshed.attack;
    currentFoe.level = refreshed.level;
    currentFoe.hp = refreshed.hp;
}
export function restoreFoeOrder(ids, heroEmoji) {
    return restoreFoeOrderForHero(ids, heroEmoji, FOES);
}
