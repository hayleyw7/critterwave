import { formatSetupBlockerMessage, getSetupBlockers as getSetupBlockersForInput, buildInitialFoeQueue, } from "./lib/game-logic.js";
import { resetDancePicker, } from "./content/dance-responses.js";
import { HERO_PICKER_ORDER, isHeroEmojiHiddenInPicker, isMobileHeroPickerViewport, resolveHeroPickerEmoji, } from "./lib/hero-groups.js";
import { resetCombatGate, } from "./lib/combat-gate.js";
import { createCombatHintsState, attackTeachText, } from "./lib/combat-hints.js";
import { stopVictoryCelebration, } from "./ui/victory-celebration.js";
import { HEROES, } from "./game/data.js";
import { el } from "./game/dom.js";
import { CAMPAIGN_WAVES, SETUP_NAME_TEACH_FLASH_MS, STORAGE_KEY, } from "./game/constants.js";
import { gameState } from "./state.js";
export function getSetupBlockers() {
    return getSetupBlockersForInput(pendingHeroEmoji, el.heroNameInput.value);
}
export function updateSetupStartButton() {
    const blockers = getSetupBlockers();
    const canStart = blockers.length === 0;
    const nameMissing = blockers.includes("enter your name");
    const hintBlockers = blockers.filter((blocker) => blocker !== "enter your name");
    el.setupStartBtn.disabled = false;
    el.setupStartBtn.classList.toggle("cmd-start-ready", canStart);
    el.heroNameInput.classList.toggle("setup-name-input--highlight", gameState.setupHintForced && nameMissing);
    el.heroNameInput.setAttribute("aria-invalid", gameState.setupHintForced && nameMissing ? "true" : "false");
    if (canStart || !gameState.setupHintForced) {
        if (canStart) {
            gameState.setupHintForced = false;
        }
        el.setupHint.hidden = true;
        el.setupHint.textContent = "";
        el.setupHint.classList.remove("setup-hint-error");
        return;
    }
    if (hintBlockers.length === 0) {
        el.setupHint.hidden = true;
        el.setupHint.textContent = "";
        el.setupHint.classList.remove("setup-hint-error");
        return;
    }
    el.setupHint.hidden = false;
    el.setupHint.textContent = formatSetupBlockerMessage(hintBlockers);
    el.setupHint.classList.add("setup-hint-error");
}
export function playSetupNameTeachFlash() {
    el.heroNameInput.classList.remove("setup-name-teach-flash");
    void el.heroNameInput.offsetWidth;
    el.heroNameInput.classList.add("setup-name-teach-flash");
    window.setTimeout(() => {
        el.heroNameInput.classList.remove("setup-name-teach-flash");
    }, SETUP_NAME_TEACH_FLASH_MS);
}
export function showSetupBlockedHint() {
    gameState.setupHintForced = true;
    updateSetupStartButton();
    if (!readHeroNameFromSetup()) {
        playSetupNameTeachFlash();
        el.heroNameInput.focus();
    }
    else {
        el.heroPicker.focus();
    }
}
export function applyHeroChoice(emoji, label) {
    gameState.player.emoji = emoji;
    gameState.player.name = label;
    gameState.pendingHeroEmoji = emoji;
    gameState.pendingHeroLabel = label;
}
export function resolvePickerHeroEmoji(emoji) {
    return resolveHeroPickerEmoji(emoji, HERO_PICKER_ORDER, isMobileHeroPickerViewport());
}
export function buildHeroPicker() {
    el.heroPicker.replaceChildren();
    const grid = document.createElement("div");
    grid.className = "emoji-picker-grid";
    const mobile = isMobileHeroPickerViewport();
    for (const hero of HEROES) {
        if (isHeroEmojiHiddenInPicker(hero.emoji, mobile)) {
            continue;
        }
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "emoji-pick";
        btn.dataset.emoji = hero.emoji;
        btn.dataset.label = hero.label;
        btn.setAttribute("aria-label", hero.label);
        const glyph = document.createElement("span");
        glyph.className = "emoji-pick-glyph";
        glyph.setAttribute("aria-hidden", "true");
        glyph.textContent = hero.emoji;
        btn.appendChild(glyph);
        if (hero.emoji === gameState.pendingHeroEmoji) {
            btn.classList.add("selected");
        }
        btn.addEventListener("click", () => {
            for (const other of el.heroPicker.querySelectorAll(".emoji-pick")) {
                other.classList.remove("selected");
            }
            btn.classList.add("selected");
            gameState.pendingHeroEmoji = hero.emoji;
            gameState.pendingHeroLabel = hero.label;
            updateSetupStartButton();
            persistSetupDraft();
        });
        grid.appendChild(btn);
    }
    el.heroPicker.appendChild(grid);
}
export function updateSetupSubtitle() {
    el.setupSubtitle.textContent = attackTeachText(CAMPAIGN_WAVES);
}
export function showSetup() {
    const save = loadSave();
    closeHeroColorPopup();
    gameState.pendingHeroEmoji = resolvePickerHeroEmoji(save.playerEmoji ?? gameState.player.emoji);
    gameState.pendingHeroLabel = getHeroLabelForEmoji(pendingHeroEmoji);
    gameState.setupHintForced = false;
    updateSetupSubtitle();
    buildHeroPicker();
    el.heroNameInput.value = save.heroName ?? "";
    gameState.pendingHeroColorTheme = resolveHeroColorTheme(save);
    buildHeroColorSwatches();
    applyHeroColorTheme(pendingHeroColorTheme);
    updateSetupStartButton();
    el.setupOverlay.classList.remove("hidden");
    el.gameShell.classList.add("setup-active");
    persistSetupDraft();
}
export function hideSetup() {
    closeHeroColorPopup();
    el.setupOverlay.classList.add("hidden");
    el.gameShell.classList.remove("setup-active");
}
export function confirmHeroAndStart() {
    const blockers = getSetupBlockers();
    if (blockers.length > 0) {
        showSetupBlockedHint();
        return false;
    }
    const heroName = readHeroNameFromSetup();
    if (!heroName) {
        showSetupBlockedHint();
        return false;
    }
    applyHeroChoice(pendingHeroEmoji, heroName);
    applyHeroColorTheme(readHeroColorThemeFromSetup());
    hideSetup();
    persistStatsOnly();
    if (foe) {
        resetGame();
    }
    return true;
}
export function resetGame() {
    gameState.turn = 1;
    gameState.wave = 1;
    gameState.defeatVerbIndex = 0;
    gameState.foeOrder = buildFoeOrder(gameState.player.emoji);
    gameState.foeQueue = buildInitialFoeQueue(foeOrder);
    gameState.deferredFoeIds = [];
    syncPlayerForCurrentWave({ healToMax: true });
    clearAllHype();
    gameState.lastFoeColorTheme = null;
    resetDancePicker();
    gameState.combatHints = createCombatHintsState();
    gameState.phase = "combat";
    applyCombatGateState(resetCombatGate(combatGateState()));
    clearCombatAnimations();
    stopVictoryCelebration(el.victoryEmojiLayer);
    el.gameOver.classList.add("hidden");
    clearLog();
    startWave();
}
export function applyNewRun() {
    persistStatsOnly();
    gameState.foe = null;
    gameState.phase = "combat";
    stopVictoryCelebration(el.victoryEmojiLayer);
    el.gameOver.classList.add("hidden");
    showSetup();
}
export function applyClearData() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(withSaveMeta({ bestWave: 0, runsPlayed: 0 })));
    renderRecords();
    gameState.foe = null;
    gameState.phase = "combat";
    stopVictoryCelebration(el.victoryEmojiLayer);
    el.gameOver.classList.add("hidden");
    showSetup();
}
export async function startNewGame() {
    await presentConfirm("newRun", applyNewRun);
}
export async function resetStats() {
    await presentConfirm("clearData", applyClearData);
}
