import { formatFoeInText as formatFoeMessage, applyHypeGain, xpProgressForWave, } from "./lib/game-logic.js";
import { tryCelebrateFirstFoeHype, tryCelebrateFirstPlayerHype, } from "./lib/combat-hints.js";
import { el } from "./game/dom.js";
import { HP_TEACH_FLASH_MS, HYPE_METER_FLASH_MS, XP_FILL_BEAT_MS, } from "./game/constants.js";
import { gameState } from "./state.js";
export function foeDisplayName() {
    return gameState.foe?.name ?? "gameState.foe";
}
export function formatFoeInText(template) {
    return formatFoeMessage(template, foeDisplayName());
}
export function renderRecords() {
    const save = loadSave();
    el.bestWave.textContent = String(save.bestWave);
    el.runs.textContent = String(save.runsPlayed);
}
export function setHpBar(fill, current, max) {
    const pct = max > 0 ? Math.max(0, Math.min(100, (current / max) * 100)) : 0;
    fill.style.width = `${pct}%`;
}
export function canBeDefeatedByNextHit(hp, incomingAttack) {
    return hp > 0 && incomingAttack >= hp;
}
export function playXpBarFullBeat() {
    if (debugInstantTransitions) {
        const { max } = xpProgressForWave(wave);
        setHpBar(el.xpFill, max, max);
        el.xpText.textContent = "100%";
        el.xpBar.setAttribute("aria-valuenow", String(max));
        el.xpBar.setAttribute("aria-valuemax", String(max));
        return Promise.resolve();
    }
    const { max } = xpProgressForWave(wave);
    setHpBar(el.xpFill, max, max);
    el.xpText.textContent = "100%";
    el.xpBar.setAttribute("aria-valuenow", String(max));
    el.xpBar.setAttribute("aria-valuemax", String(max));
    return pause(XP_FILL_BEAT_MS);
}
export function playFirstHypeFlash(wrap) {
    wrap.classList.add("hype-first-dance-flash");
    window.setTimeout(() => {
        wrap.classList.remove("hype-first-dance-flash");
    }, HYPE_METER_FLASH_MS);
}
export function gainPlayerHype(amount) {
    if (amount <= 0) {
        return;
    }
    gameState.hypeLevel = applyHypeGain(hypeLevel, amount);
}
export function gainFoeHype(amount) {
    if (amount <= 0) {
        return;
    }
    gameState.foeHypeLevel = applyHypeGain(foeHypeLevel, amount);
}
export function syncFirstHypeFlashes() {
    if (suppressTeachFlashesThisRender) {
        return;
    }
    const skipPlayer = gameState.skipPlayerHypeTeachThisRender;
    gameState.skipPlayerHypeTeachThisRender = false;
    if (!skipPlayer) {
        const player = tryCelebrateFirstPlayerHype(combatHints, hypeLevel);
        gameState.combatHints = gameState.player.flags;
        if (gameState.player.flashFirstHype) {
            playFirstHypeFlash(el.playerHypeWrap);
        }
    }
    const foe = tryCelebrateFirstFoeHype(combatHints, foeHypeLevel);
    gameState.combatHints = gameState.foe.flags;
    if (gameState.foe.flashFirstHype) {
        playFirstHypeFlash(el.foeHypeWrap);
    }
}
export function playHpBarTeachFlash(fill, className) {
    const bar = fill.parentElement;
    if (!bar) {
        return;
    }
    bar.classList.remove(className);
    void bar.offsetWidth;
    bar.classList.add(className);
    window.setTimeout(() => bar.classList.remove(className), HP_TEACH_FLASH_MS);
}
export function playFirstHealHpFlash() {
    playHpBarTeachFlash(el.playerHpFill, "hp-first-heal-flash");
}
export function playFirstPlayerDamageHpFlash() {
    playHpBarTeachFlash(el.playerHpFill, "hp-first-damage-flash");
}
export function playFirstAttackFoeHpFlash() {
    playHpBarTeachFlash(el.foeHpFill, "hp-first-attack-flash");
}
export function playFirstWaveVictoryHealHpFlash() {
    playHpBarTeachFlash(el.playerHpFill, "hp-first-gameState.wave-heal-flash");
}
