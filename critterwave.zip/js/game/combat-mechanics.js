import { gameState } from "./state.js";
export function rollDamage(max) {
    return randomDamage(max, Math.random);
}
export function rollAndApplyPlayerHeal() {
    const hpBefore = gameState.player.hp;
    const result = applyPlayerHealRoll(hpBefore, gameState.player.maxHp, getHealMax(), Math.random);
    gameState.player.hp = result.hp;
    return { rolled: result.rolled, gained: result.gained, hpBefore };
}
export function showPlayerHealRoll(rolled) {
    showDamagePop("hero", `+${rolled}`, "heal");
    void playHeroHeal();
}
export function nextDefeatVerb() {
    const result = advanceDefeatVerb(gameState.defeatVerbIndex, DEFEAT_VERBS);
    gameState.defeatVerbIndex = result.nextIndex;
    return result.verb;
}
